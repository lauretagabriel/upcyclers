/* @ds-bundle: {"format":4,"namespace":"UpcyclersDesignSystem_2f4fb9","components":[{"name":"Card","sourcePath":"components/cards/Card.jsx"},{"name":"EntryCard","sourcePath":"components/cards/EntryCard.jsx"},{"name":"MediaCard","sourcePath":"components/cards/MediaCard.jsx"},{"name":"PersonCard","sourcePath":"components/cards/PersonCard.jsx"},{"name":"ProductCard","sourcePath":"components/cards/ProductCard.jsx"},{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Stat","sourcePath":"components/core/Stat.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Gallery","sourcePath":"components/media/Gallery.jsx"},{"name":"AnnouncementBar","sourcePath":"components/navigation/AnnouncementBar.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"Header","sourcePath":"components/navigation/Header.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"Accordion","sourcePath":"components/sections/Accordion.jsx"},{"name":"ChallengeHero","sourcePath":"components/sections/ChallengeHero.jsx"},{"name":"Countdown","sourcePath":"components/sections/Countdown.jsx"},{"name":"Hero","sourcePath":"components/sections/Hero.jsx"}],"sourceHashes":{"assets/image-slot.js":"0394ad34f685","components/cards/Card.jsx":"326322d5e354","components/cards/EntryCard.jsx":"1a3b85ae877c","components/cards/MediaCard.jsx":"34a0dcfa41ad","components/cards/PersonCard.jsx":"5444609c4058","components/cards/ProductCard.jsx":"0b7732a2adf4","components/core/Avatar.jsx":"af773f8392fc","components/core/Badge.jsx":"c2c39d02df7e","components/core/Button.jsx":"8377fe1daf5e","components/core/Eyebrow.jsx":"7d8b4ba116ae","components/core/Icon.jsx":"7f6ac89e325c","components/core/Stat.jsx":"fc071946d259","components/core/Tag.jsx":"3ae7a050eb37","components/media/Gallery.jsx":"9eb6fbcbeee1","components/navigation/AnnouncementBar.jsx":"db71fb2dba17","components/navigation/Footer.jsx":"25acd9fa78cc","components/navigation/Header.jsx":"16eb88be4518","components/navigation/Tabs.jsx":"4ed1ef351a24","components/sections/Accordion.jsx":"f5c1c541c97a","components/sections/ChallengeHero.jsx":"1ec2994ad0c1","components/sections/Countdown.jsx":"925fe4a19907","components/sections/Hero.jsx":"96985094419d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.UpcyclersDesignSystem_2f4fb9 = window.UpcyclersDesignSystem_2f4fb9 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// assets/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;color:rgba(0,0,0,.55);' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(0,0,0,.04)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px;text-decoration-color:rgba(0,0,0,.25)}' + '.empty:hover .sub u{color:rgba(0,0,0,.75);text-decoration-color:currentColor}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed rgba(0,0,0,.25);' + '  transition:border-color .12s}' + ':host([data-over]) .ring{border-color:#c96442}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(0,0,0,.12);border-top-color:rgba(0,0,0,.45);' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }
    attributeChangedCallback() {
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/image-slot.js", error: String((e && e.message) || e) }); }

// components/cards/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — base surface container. Hairline border, brand radius, solid/inset fill.
 * The building block other cards compose; use directly for arbitrary panels.
 */
function Card({
  children,
  surface = 'panel',
  padded = true,
  hoverable = false,
  as = 'div',
  href,
  onClick,
  className,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const fills = {
    panel: 'var(--panel)',
    surface: 'var(--card-bg)',
    plain: 'transparent'
  };
  const bg = fills[surface] || surface;
  const interactive = hoverable || typeof onClick === 'function' || !!href;
  const leave = () => setHover(false);
  const handleClick = e => {
    setHover(false);
    if (onClick) onClick(e);
  };
  const merged = {
    background: bg,
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-md)',
    overflow: 'hidden',
    padding: padded ? 'var(--space-6)' : 0,
    display: 'block',
    textDecoration: 'none',
    color: 'inherit',
    transition: 'border-color var(--t)',
    ...(interactive ? {
      cursor: 'pointer'
    } : null),
    ...(interactive && hover ? {
      border: '1px solid var(--border-strong)'
    } : null),
    ...style
  };
  const Tag = href ? 'a' : as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    onClick: interactive ? handleClick : onClick,
    className: ['uc-card', className].filter(Boolean).join(' '),
    style: merged,
    onPointerEnter: interactive ? () => setHover(true) : undefined,
    onPointerLeave: interactive ? leave : undefined,
    onPointerCancel: interactive ? leave : undefined,
    onBlur: interactive ? leave : undefined
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: 34,
  md: 40,
  lg: 46,
  xl: 56
};

/**
 * Avatar — circular creator/seller mark. Renders an image when `src` is given,
 * otherwise initials on a chip fill.
 */
function Avatar({
  name,
  src,
  initials,
  size = 'md',
  ring = false,
  alt,
  className,
  style,
  ...rest
}) {
  const px = typeof size === 'number' ? size : SIZES[size] || 40;
  const auto = (name || '').trim().split(/\s+/).map(w => w[0]).slice(0, 2).join('').toUpperCase();
  const label = initials || auto || '?';
  const box = {
    width: px,
    height: px,
    flex: '0 0 auto',
    borderRadius: '50%',
    overflow: 'hidden',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'var(--chip)',
    color: 'var(--fg)',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-extrabold)',
    fontSize: Math.round(px * 0.36),
    lineHeight: 1,
    border: ring ? '1px solid var(--border-strong)' : 'none',
    ...style
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['uc-avatar', className].filter(Boolean).join(' '),
    style: box,
    title: name
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt || name || '',
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  }) : label);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — tiny uppercase label. Verified buyer, Seller, challenge rank, "New".
 */
function Badge({
  children,
  tone = 'neutral',
  icon,
  className,
  style,
  ...rest
}) {
  const tones = {
    neutral: {
      background: 'var(--chip)',
      color: 'var(--muted)'
    },
    accent: {
      background: 'var(--accent-soft)',
      color: 'var(--accent-2)'
    },
    solid: {
      background: 'var(--accent-2)',
      color: '#fff'
    },
    invert: {
      background: 'var(--fg)',
      color: 'var(--bg)'
    }
  };
  const merged = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '4px',
    fontFamily: 'var(--font-sans)',
    fontSize: '10px',
    fontWeight: 'var(--fw-extrabold)',
    letterSpacing: '.06em',
    textTransform: 'uppercase',
    padding: '3px 8px',
    borderRadius: 'var(--radius-pill)',
    lineHeight: 1.2,
    whiteSpace: 'nowrap',
    ...(tones[tone] || tones.neutral),
    ...style
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    className: ['uc-badge', className].filter(Boolean).join(' '),
    style: merged
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex'
    }
  }, icon) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    padding: '9px 18px',
    fontSize: '13px'
  },
  md: {
    padding: '13px 26px',
    fontSize: '14px'
  },
  lg: {
    padding: '16px 34px',
    fontSize: '16px'
  }
};

/**
 * Button — the brand's pill button. White(→ink) fill for primary actions,
 * hairline outline for secondary, bare text for inline "→" links.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  onClick,
  iconLeft,
  iconRight,
  block = false,
  disabled = false,
  type = 'button',
  className,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const on = hover && !disabled;
  const base = {
    display: block ? 'flex' : 'inline-flex',
    width: block ? '100%' : undefined,
    alignItems: 'center',
    justifyContent: 'center',
    gap: '10px',
    fontFamily: 'var(--font-sans)',
    fontSize: s.fontSize,
    fontWeight: 700,
    lineHeight: 1,
    letterSpacing: '.01em',
    padding: s.padding,
    borderRadius: 'var(--radius-pill)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    textDecoration: 'none',
    whiteSpace: 'nowrap',
    boxSizing: 'border-box',
    transition: 'opacity var(--t-fast), background var(--t-fast), border-color var(--t-fast), color var(--t-fast), transform var(--t-fast)',
    transform: active && !disabled ? 'scale(var(--press-scale))' : 'none',
    opacity: disabled ? 0.4 : 1
  };
  const variants = {
    primary: {
      background: 'var(--btn-bg)',
      color: 'var(--btn-fg)',
      ...(on ? {
        opacity: 0.86
      } : null)
    },
    secondary: {
      background: on ? 'var(--chip)' : 'transparent',
      color: 'var(--fg)',
      borderColor: on ? 'var(--fg)' : 'var(--border-strong)'
    },
    ghost: {
      background: 'transparent',
      color: on ? 'var(--accent-2)' : 'var(--fg)',
      padding: '2px 0',
      borderRadius: 0
    }
  };
  const cls = ['uc-button', className].filter(Boolean).join(' ');
  const merged = {
    ...base,
    ...(variants[variant] || variants.primary),
    ...style
  };
  const bind = {
    className: cls,
    style: merged,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    ...rest
  };
  const inner = /*#__PURE__*/React.createElement(React.Fragment, null, iconLeft ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flex: '0 0 auto'
    }
  }, iconLeft) : null, children != null ? /*#__PURE__*/React.createElement("span", null, children) : null, iconRight ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flex: '0 0 auto'
    }
  }, iconRight) : null);
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", _extends({
      href: href,
      onClick: onClick
    }, bind), inner);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    onClick: onClick,
    disabled: disabled,
    "aria-disabled": disabled || undefined
  }, bind), inner);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Eyebrow — small uppercase kicker above titles. Red on dark (accent),
 * ink on light. The brand's signature section label.
 */
function Eyebrow({
  children,
  tone = 'accent',
  as = 'div',
  className,
  style,
  ...rest
}) {
  const Tag = as;
  const color = tone === 'accent' ? 'var(--accent)' : tone === 'muted' ? 'var(--muted-2)' : 'var(--fg)';
  const merged = {
    fontFamily: 'var(--font-sans)',
    fontSize: 'var(--fs-eyebrow)',
    fontWeight: 'var(--fw-bold)',
    letterSpacing: 'var(--ls-eyebrow)',
    textTransform: 'uppercase',
    lineHeight: 1.2,
    color,
    ...style
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: ['uc-eyebrow', className].filter(Boolean).join(' '),
    style: merged
  }, rest), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
/**
 * Icon — official Lucide (https://lucide.dev, ISC), loaded from the pinned CDN
 * UMD build. Any Lucide icon name works (kebab-case, e.g. "arrow-right",
 * "shopping-bag"). The component reads the icon's node data off window.lucide
 * and renders it into an <svg> we control (size / stroke / fill / color).
 *
 * A small inline geometry fallback covers the core UI glyphs so icons still
 * paint before the CDN resolves and if it is ever unreachable (offline).
 */
const LUCIDE_VERSION = '0.552.0';
const LUCIDE_SRC = `https://unpkg.com/lucide@${LUCIDE_VERSION}/dist/umd/lucide.min.js`;

// Offline / pre-load fallback — inner markup on the Lucide 24px grid.
const FALLBACK = {
  'arrow-right': '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  'arrow-left': '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  'arrow-up-right': '<path d="M7 7h10v10"/><path d="M7 17 17 7"/>',
  'chevron-left': '<path d="m15 18-6-6 6-6"/>',
  'chevron-right': '<path d="m9 18 6-6-6-6"/>',
  'chevron-down': '<path d="m6 9 6 6 6-6"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
  heart: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  play: '<polygon points="6 3 20 12 6 21 6 3"/>'
};
const toPascal = name => String(name).split(/[-_]/).map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('');

// Singleton loader for the Lucide UMD global. Resolves null on failure so the
// caller falls back to inline geometry instead of throwing.
let lucidePromise = null;
function loadLucide() {
  if (typeof window === 'undefined') return Promise.resolve(null);
  if (window.lucide) return Promise.resolve(window.lucide);
  if (lucidePromise) return lucidePromise;
  lucidePromise = new Promise(resolve => {
    const done = () => resolve(window.lucide || null);
    const existing = document.querySelector('script[data-lucide-cdn]');
    if (existing) {
      existing.addEventListener('load', done);
      existing.addEventListener('error', () => resolve(null));
      if (window.lucide) done();
      return;
    }
    const s = document.createElement('script');
    s.src = LUCIDE_SRC;
    s.async = true;
    s.crossOrigin = 'anonymous';
    s.setAttribute('data-lucide-cdn', LUCIDE_VERSION);
    s.onload = done;
    s.onerror = () => resolve(null);
    document.head.appendChild(s);
  });
  return lucidePromise;
}

// Lucide node -> React element. Nodes are [tag, attrs, children?].
function renderNode(node, key) {
  if (!Array.isArray(node)) return null;
  const [tag, attrs = {}, children] = node;
  return React.createElement(tag, {
    key,
    ...attrs
  }, Array.isArray(children) ? children.map((c, i) => renderNode(c, i)) : undefined);
}
function getIconNode(name) {
  const lucide = typeof window !== 'undefined' ? window.lucide : null;
  if (!lucide) return null;
  const p = toPascal(name);
  const node = lucide.icons && lucide.icons[p] || lucide[p];
  return Array.isArray(node) ? node : null;
}
function Icon({
  name,
  size = 18,
  strokeWidth = 2,
  filled = false,
  fill,
  color = 'currentColor',
  className,
  style,
  ...rest
}) {
  // Re-render once the CDN global becomes available.
  const [, bump] = React.useReducer(x => x + 1, 0);
  React.useEffect(() => {
    if (typeof window !== 'undefined' && !window.lucide) {
      let alive = true;
      loadLucide().then(() => {
        if (alive) bump();
      });
      return () => {
        alive = false;
      };
    }
  }, []);
  const svgProps = {
    xmlns: 'http://www.w3.org/2000/svg',
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: fill != null ? fill : filled ? 'currentColor' : 'none',
    stroke: color,
    strokeWidth,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    className: ['uc-icon', className].filter(Boolean).join(' '),
    style: {
      display: 'inline-block',
      flex: '0 0 auto',
      verticalAlign: 'middle',
      ...style
    },
    'aria-hidden': true,
    focusable: false,
    ...rest
  };
  const node = getIconNode(name);
  if (node) {
    return React.createElement('svg', svgProps, node.map((c, i) => renderNode(c, i)));
  }
  const inner = FALLBACK[name];
  if (!inner) return null; // unknown name, CDN not ready yet — paints on next render
  return React.createElement('svg', {
    ...svgProps,
    dangerouslySetInnerHTML: {
      __html: inner
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/cards/MediaCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const PlayGlyph = () => /*#__PURE__*/React.createElement("span", {
  style: {
    width: 52,
    height: 52,
    borderRadius: '50%',
    background: 'rgba(0,0,0,.55)',
    backdropFilter: 'var(--blur)',
    WebkitBackdropFilter: 'var(--blur)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    border: '1px solid rgba(255,255,255,.25)'
  }
}, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
  name: "play",
  size: 18,
  filled: true,
  color: "#fff",
  style: {
    marginLeft: 3
  }
}));

/**
 * MediaCard — the brand's image/video card. The media sits in an inset frame
 * with its own rounded corners (`frame`, on by default); pass `frame={false}`
 * for an edge-to-edge thumbnail. Hover lifts the card and gently zooms the
 * media. Built to open a Gallery on click.
 */
function MediaCard({
  image,
  video,
  poster,
  alt = '',
  aspect = '3/4',
  fit = 'cover',
  frame = true,
  topLeft,
  topRight,
  children,
  bodyPadding,
  onClick,
  href,
  hoverable = true,
  className,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const isVideo = !!video;
  const thumb = poster || image;
  const interactive = hoverable || typeof onClick === 'function' || !!href;
  const Tag = href ? 'a' : 'div';
  const leave = () => setHover(false);
  const handleClick = e => {
    setHover(false);
    if (onClick) onClick(e);
  };
  const bodyPad = bodyPadding != null ? bodyPadding : frame ? '12px 0 2px' : '14px 15px 16px';
  return /*#__PURE__*/React.createElement(Tag, _extends({
    href: href,
    className: ['uc-mediacard', className].filter(Boolean).join(' '),
    style: {
      display: 'block',
      background: 'var(--card-bg)',
      border: '1px solid var(--border)',
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      textDecoration: 'none',
      color: 'inherit',
      padding: frame ? 'var(--space-2)' : 0,
      cursor: interactive ? 'pointer' : 'default',
      transition: 'border-color var(--t)',
      ...(interactive && hover ? {
        border: '1px solid var(--border-strong)'
      } : null),
      ...style
    },
    onClick: interactive ? handleClick : onClick,
    onPointerEnter: interactive ? () => setHover(true) : undefined,
    onPointerLeave: interactive ? leave : undefined,
    onPointerCancel: interactive ? leave : undefined,
    onBlur: interactive ? leave : undefined
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: aspect,
      width: '100%',
      overflow: 'hidden',
      background: 'var(--chip)',
      borderRadius: frame ? 'var(--radius-sm)' : 0
    }
  }, thumb ? /*#__PURE__*/React.createElement("img", {
    src: thumb,
    alt: alt,
    style: {
      width: '100%',
      height: '100%',
      objectFit: fit,
      display: 'block',
      transition: 'transform var(--t-slow)',
      transform: interactive && hover ? 'scale(1.04)' : 'none'
    }
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--faint)',
      fontSize: 13
    }
  }, alt || 'Media'), isVideo ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement(PlayGlyph, null)) : null, topLeft ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 10,
      left: 10
    }
  }, topLeft) : null, topRight ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 10,
      right: 10
    }
  }, topRight) : null), children != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: bodyPad
    }
  }, children) : null);
}
Object.assign(__ds_scope, { MediaCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/MediaCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/EntryCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * EntryCard — a challenge entry tile: media with a rank badge, title, creator
 * handle (with country flag) and a heart vote count. Supports image or video.
 */
function EntryCard({
  image,
  video,
  poster,
  alt,
  aspect = '3/4',
  rank,
  title,
  handle,
  flag,
  votes,
  href,
  onClick,
  className,
  style,
  ...rest
}) {
  const rankBadge = rank != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: '50%',
      background: 'rgba(0,0,0,.55)',
      backdropFilter: 'var(--blur)',
      WebkitBackdropFilter: 'var(--blur)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 13,
      color: '#fff'
    }
  }, rank) : null;
  return /*#__PURE__*/React.createElement(__ds_scope.MediaCard, _extends({
    image: image,
    video: video,
    poster: poster,
    alt: alt || title,
    aspect: aspect,
    href: href,
    onClick: onClick,
    className: className,
    style: style,
    topLeft: rankBadge
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 15,
      lineHeight: 1.3,
      color: 'var(--fg)',
      minHeight: 39
    }
  }, title), handle || flag ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      marginTop: 10,
      color: 'var(--muted)',
      fontSize: 13
    }
  }, flag ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15
    }
  }, flag) : null, /*#__PURE__*/React.createElement("span", null, handle)) : null, votes != null ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      marginTop: 9,
      color: 'var(--muted)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "heart",
    size: 14,
    filled: true,
    color: "var(--accent)"
  }), /*#__PURE__*/React.createElement("span", null, votes, " votes")) : null);
}
Object.assign(__ds_scope, { EntryCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/EntryCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/PersonCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * PersonCard — a creator or challenge judge: portrait media over name, role,
 * short bio and an optional link. Wider 4/3 media by default.
 */
function PersonCard({
  image,
  video,
  poster,
  alt,
  aspect = '4/3',
  name,
  role,
  bio,
  link,
  href,
  onClick,
  className,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.MediaCard, _extends({
    image: image,
    video: video,
    poster: poster,
    alt: alt || name,
    aspect: aspect,
    href: href,
    onClick: onClick,
    hoverable: !!(href || onClick),
    className: className,
    style: style,
    bodyPadding: "20px 22px 24px"
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-extrabold)',
      fontSize: 18,
      letterSpacing: '.03em',
      textTransform: 'uppercase',
      color: 'var(--fg)'
    }
  }, name), role ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent)',
      fontSize: 13,
      fontWeight: 'var(--fw-bold)',
      margin: '4px 0 12px'
    }
  }, role) : null, bio ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--muted)',
      fontSize: 14,
      lineHeight: 1.55
    }
  }, bio) : null, link ? /*#__PURE__*/React.createElement("a", {
    href: link.href || '#',
    style: {
      display: 'inline-block',
      marginTop: 14,
      fontSize: 13,
      fontWeight: 'var(--fw-bold)'
    }
  }, link.label || 'See more', " ", /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-right",
    size: 14
  })) : null);
}
Object.assign(__ds_scope, { PersonCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/PersonCard.jsx", error: String((e && e.message) || e) }); }

// components/cards/ProductCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function SaveButton({
  saved,
  defaultSaved,
  onSave
}) {
  const controlled = saved !== undefined;
  const [internal, setInternal] = React.useState(!!defaultSaved);
  const isSaved = controlled ? saved : internal;
  const toggle = e => {
    e.preventDefault();
    e.stopPropagation();
    if (!controlled) setInternal(v => !v);
    if (onSave) onSave();
  };
  return /*#__PURE__*/React.createElement("button", {
    "aria-label": isSaved ? 'Saved' : 'Save',
    "aria-pressed": isSaved,
    onClick: toggle,
    style: {
      width: 34,
      height: 34,
      borderRadius: '50%',
      border: '1px solid rgba(255,255,255,.25)',
      background: 'rgba(0,0,0,.5)',
      backdropFilter: 'var(--blur)',
      WebkitBackdropFilter: 'var(--blur)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      padding: 0,
      color: isSaved ? 'var(--accent-2)' : '#fff',
      fontSize: 15,
      lineHeight: 1,
      transition: 'color var(--t)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "heart",
    size: 17,
    filled: isSaved
  }));
}

/**
 * ProductCard — a marketplace listing: media, title, seller, price and a save
 * (heart) control. Composes MediaCard so it supports image OR video.
 */
function ProductCard({
  image,
  video,
  poster,
  alt,
  aspect = '3/4',
  title,
  seller,
  price,
  hearts,
  badge,
  saved,
  defaultSaved,
  onSave,
  href,
  onClick,
  className,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.MediaCard, _extends({
    image: image,
    video: video,
    poster: poster,
    alt: alt || title,
    aspect: aspect,
    href: href,
    onClick: onClick,
    className: className,
    style: style,
    topLeft: badge,
    topRight: /*#__PURE__*/React.createElement(SaveButton, {
      saved: saved,
      defaultSaved: defaultSaved,
      onSave: onSave
    })
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 15,
      lineHeight: 1.3,
      color: 'var(--fg)'
    }
  }, title), seller ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: seller.name,
    src: seller.avatar,
    initials: seller.initials,
    size: 22
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted-2)',
      fontSize: 13,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, seller.handle || seller.name)) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      justifyContent: 'space-between',
      gap: 8,
      marginTop: 12
    }
  }, price != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-extrabold)',
      fontSize: 17,
      letterSpacing: '-.01em',
      color: 'var(--fg)'
    }
  }, price) : /*#__PURE__*/React.createElement("span", null), hearts != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      color: 'var(--muted-2)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "heart",
    size: 13,
    filled: true,
    color: "var(--accent)"
  }), hearts) : null));
}
Object.assign(__ds_scope, { ProductCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/cards/ProductCard.jsx", error: String((e && e.message) || e) }); }

// components/core/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const NUM = {
  sm: '40px',
  md: '56px',
  lg: 'var(--fs-stat)'
};

/**
 * Stat — big Bebas Neue number over a label. Used for impact metrics, prizes
 * and judging weights. Set `accent` to color the number red (one per group).
 */
function Stat({
  value,
  label,
  sublabel,
  size = 'md',
  accent = false,
  align = 'left',
  className,
  style,
  ...rest
}) {
  const wrap = {
    textAlign: align,
    ...style
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['uc-stat', className].filter(Boolean).join(' '),
    style: wrap
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--fw-display)',
      fontSize: NUM[size] || NUM.md,
      lineHeight: 'var(--lh-tight)',
      letterSpacing: 'var(--ls-display)',
      color: accent ? 'var(--accent)' : 'var(--fg)'
    }
  }, value), label ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-bold)',
      fontSize: '14px',
      marginTop: '8px',
      color: 'var(--fg)'
    }
  }, label) : null, sublabel ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '12.5px',
      marginTop: '4px',
      color: 'var(--muted-2)'
    }
  }, sublabel) : null);
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Stat.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    padding: '5px 12px',
    fontSize: '12px'
  },
  md: {
    padding: '9px 16px',
    fontSize: '14px'
  }
};

/**
 * Tag — pill chip for materials, categories, filters and selectable options.
 */
function Tag({
  children,
  variant = 'default',
  size = 'md',
  selected = false,
  icon,
  onClick,
  className,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const interactive = typeof onClick === 'function';
  const looks = {
    default: {
      background: 'var(--chip)',
      color: 'var(--fg)',
      border: '1px solid var(--border-strong)'
    },
    outline: {
      background: 'transparent',
      color: 'var(--muted)',
      border: '1px solid var(--border-strong)'
    },
    solid: {
      background: 'var(--accent-soft)',
      color: 'var(--accent-2)',
      border: '1px solid transparent'
    }
  };
  const sel = selected ? {
    background: 'var(--fg)',
    color: 'var(--bg)',
    border: '1px solid var(--fg)'
  } : null;
  const merged = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '7px',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-semibold)',
    fontSize: s.fontSize,
    lineHeight: 1,
    padding: s.padding,
    borderRadius: 'var(--radius-pill)',
    cursor: interactive ? 'pointer' : 'default',
    transition: 'background var(--t-fast), border-color var(--t-fast), color var(--t-fast)',
    ...(looks[variant] || looks.default),
    ...(interactive && hover && !selected ? {
      borderColor: 'var(--fg)'
    } : null),
    ...sel,
    ...style
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    className: ['uc-tag', className].filter(Boolean).join(' '),
    style: merged,
    onClick: onClick,
    onMouseEnter: interactive ? () => setHover(true) : undefined,
    onMouseLeave: interactive ? () => setHover(false) : undefined,
    role: interactive ? 'button' : undefined,
    tabIndex: interactive ? 0 : undefined
  }, rest), icon ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex'
    }
  }, icon) : null, children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/media/Gallery.jsx
try { (() => {
function RoundBtn({
  label,
  onClick,
  size = 48,
  children,
  style
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    "aria-label": label,
    onClick: e => {
      e.stopPropagation();
      onClick();
    },
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      width: size,
      height: size,
      borderRadius: '50%',
      flex: '0 0 auto',
      border: '1px solid rgba(255,255,255,.22)',
      background: h ? 'rgba(255,255,255,.16)' : 'rgba(255,255,255,.06)',
      backdropFilter: 'var(--blur)',
      WebkitBackdropFilter: 'var(--blur)',
      color: '#fff',
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 0,
      transition: 'background var(--t-fast)',
      ...style
    }
  }, children);
}

/**
 * Gallery — full-screen media lightbox for cards that hold images or videos.
 * Left/right arrows, a thumbnail rail, a close button, image + video support,
 * and graceful keyboard handling (Esc closes, ←/→ navigate). Controlled via
 * `open` + `onClose`; the index is controlled (`index`/`onIndexChange`) or
 * internal (`defaultIndex`).
 */
function Gallery({
  open = false,
  items = [],
  index,
  defaultIndex = 0,
  onIndexChange,
  onClose,
  showThumbnails = true,
  loop = true,
  className,
  style
}) {
  const [internal, setInternal] = React.useState(defaultIndex);
  const controlled = index !== undefined;
  const cur = controlled ? index : internal;
  const go = React.useCallback(i => {
    const n = items.length;
    if (n === 0) return;
    const next = loop ? (i % n + n) % n : Math.max(0, Math.min(n - 1, i));
    if (!controlled) setInternal(next);
    if (onIndexChange) onIndexChange(next);
  }, [items.length, loop, controlled, onIndexChange]);
  React.useEffect(() => {
    if (!open) return undefined;
    const onKey = e => {
      if (e.key === 'Escape') {
        if (onClose) onClose();
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        go(cur - 1);
      } else if (e.key === 'ArrowRight') {
        e.preventDefault();
        go(cur + 1);
      }
    };
    window.addEventListener('keydown', onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, cur, go, onClose]);
  if (!open || items.length === 0) return null;
  const item = items[cur] || items[0];
  const multi = items.length > 1;
  const norm = m => typeof m === 'string' ? {
    type: 'image',
    src: m
  } : m;
  const it = norm(item);
  return /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    "aria-label": "Media gallery",
    className: ['uc-gallery', className].filter(Boolean).join(' '),
    onClick: () => onClose && onClose(),
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 'var(--z-overlay)',
      background: 'rgba(8,8,8,.94)',
      backdropFilter: 'var(--blur-strong)',
      WebkitBackdropFilter: 'var(--blur-strong)',
      display: 'flex',
      flexDirection: 'column',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '18px clamp(16px,4vw,30px)',
      flex: '0 0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-bold)',
      fontSize: 14,
      color: 'rgba(255,255,255,.72)',
      letterSpacing: '.04em'
    }
  }, multi ? `${cur + 1} / ${items.length}` : ''), /*#__PURE__*/React.createElement(RoundBtn, {
    label: "Close gallery",
    onClick: () => onClose && onClose(),
    size: 42
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 18,
    strokeWidth: 2.2
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 auto',
      position: 'relative',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '0 clamp(12px,5vw,72px)',
      minHeight: 0
    }
  }, multi ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 'clamp(10px,3vw,26px)',
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }, /*#__PURE__*/React.createElement(RoundBtn, {
    label: "Previous",
    onClick: () => go(cur - 1)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-left",
    size: 20,
    strokeWidth: 2.2
  }))) : null, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      maxWidth: 'min(1100px,86vw)',
      maxHeight: '100%',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 14
    }
  }, it.type === 'video' ? /*#__PURE__*/React.createElement("video", {
    key: cur,
    src: it.src,
    poster: it.poster,
    controls: true,
    autoPlay: true,
    playsInline: true,
    style: {
      maxWidth: '100%',
      maxHeight: '68vh',
      borderRadius: 'var(--radius-md)',
      background: '#000',
      display: 'block',
      boxShadow: 'var(--shadow-overlay)'
    }
  }) : /*#__PURE__*/React.createElement("img", {
    key: cur,
    src: it.src,
    alt: it.alt || '',
    style: {
      maxWidth: '100%',
      maxHeight: '72vh',
      objectFit: 'contain',
      borderRadius: 'var(--radius-md)',
      display: 'block',
      boxShadow: 'var(--shadow-overlay)'
    }
  }), it.caption ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'rgba(255,255,255,.7)',
      fontSize: 14,
      textAlign: 'center',
      maxWidth: 640
    }
  }, it.caption) : null), multi ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 'clamp(10px,3vw,26px)',
      top: '50%',
      transform: 'translateY(-50%)'
    }
  }, /*#__PURE__*/React.createElement(RoundBtn, {
    label: "Next",
    onClick: () => go(cur + 1)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-right",
    size: 20,
    strokeWidth: 2.2
  }))) : null), showThumbnails && multi ? /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      flex: '0 0 auto',
      display: 'flex',
      gap: 10,
      justifyContent: 'center',
      flexWrap: 'nowrap',
      overflowX: 'auto',
      padding: '18px clamp(16px,4vw,30px) 24px',
      scrollbarWidth: 'none'
    }
  }, items.map((m, i) => {
    const t = norm(m);
    const on = i === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      "aria-label": `Go to item ${i + 1}`,
      onClick: () => go(i),
      style: {
        position: 'relative',
        width: 64,
        height: 64,
        flex: '0 0 auto',
        padding: 0,
        cursor: 'pointer',
        borderRadius: 'var(--radius-sm)',
        overflow: 'hidden',
        background: 'var(--chip)',
        border: on ? '2px solid #fff' : '2px solid rgba(255,255,255,.2)',
        opacity: on ? 1 : 0.6,
        transition: 'opacity var(--t-fast), border-color var(--t-fast)'
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: t.poster || t.src,
      alt: "",
      style: {
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        display: 'block'
      }
    }), t.type === 'video' ? /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        inset: 0,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: 'rgba(0,0,0,.25)'
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "play",
      size: 14,
      filled: true,
      color: "#fff"
    })) : null);
  })) : null);
}
Object.assign(__ds_scope, { Gallery });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/media/Gallery.jsx", error: String((e && e.message) || e) }); }

// components/navigation/AnnouncementBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AnnouncementBar — thin strip above the header for a running message
 * (e.g. a challenge countdown) with an optional trailing link.
 */
function AnnouncementBar({
  children,
  action,
  align = 'center',
  tone = 'default',
  className,
  style,
  ...rest
}) {
  const accent = tone === 'accent';
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['uc-announcement', className].filter(Boolean).join(' '),
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      justifyContent: align === 'between' ? 'space-between' : 'center',
      gap: '6px 18px',
      padding: '14px var(--gutter)',
      boxSizing: 'border-box',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      letterSpacing: '.2px',
      background: accent ? 'var(--accent)' : 'var(--bg)',
      color: accent ? '#fff' : 'var(--muted-2)',
      borderBottom: accent ? 'none' : '1px solid var(--border)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'baseline',
      gap: 4
    }
  }, children), action ? /*#__PURE__*/React.createElement("a", {
    href: action.href || '#',
    onClick: action.onClick,
    style: {
      color: accent ? '#fff' : 'var(--fg)',
      fontWeight: 'var(--fw-bold)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, action.label, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "arrow-right",
    size: 15
  })) : null);
}
Object.assign(__ds_scope, { AnnouncementBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/AnnouncementBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Footer — the shared site footer: brand lockup + tagline + social row on the
 * left, a sitemap grid on the right, and a hairline bottom bar with the
 * copyright and legal links. Columns, socials, tagline and copyright all have
 * brand defaults, so `<Footer logoSrc={LOGO} />` renders the full, consistent
 * footer used across every page. Pass props to override any part.
 */

// Brand marks (Simple Icons, CC0). 24×24, single fill path.
const SOCIAL_ICONS = {
  instagram: {
    label: 'Instagram',
    path: 'M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z'
  },
  tiktok: {
    label: 'TikTok',
    path: 'M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z'
  },
  x: {
    label: 'X',
    path: 'M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z'
  },
  facebook: {
    label: 'Facebook',
    path: 'M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z'
  },
  youtube: {
    label: 'YouTube',
    path: 'M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z'
  }
};
const DEFAULT_COLUMNS = [{
  title: 'Challenge',
  links: [{
    label: 'Current challenge'
  }, {
    label: 'Past challenges'
  }, {
    label: 'Rules'
  }, {
    label: 'Hall of Fame'
  }]
}, {
  title: 'Community',
  links: [{
    label: 'Explore'
  }, {
    label: 'Techniques'
  }, {
    label: 'Featured creators'
  }, {
    label: 'Countries'
  }]
}, {
  title: 'Marketplace',
  links: [{
    label: 'Reworked Vintage'
  }, {
    label: 'Secondhand'
  }, {
    label: 'Deadstock'
  }, {
    label: 'Sell'
  }]
}, {
  title: 'Upcyclers',
  links: [{
    label: 'About'
  }, {
    label: 'Sustainability'
  }, {
    label: 'Help'
  }, {
    label: 'Contact'
  }]
}];
const DEFAULT_SOCIALS = [{
  type: 'instagram',
  href: 'https://www.instagram.com/upcyclers_/'
}, {
  type: 'tiktok',
  href: 'https://www.tiktok.com/@upcyclers_'
}, {
  type: 'x',
  href: 'https://x.com/Upcyclers_'
}, {
  type: 'facebook',
  href: 'https://www.facebook.com/profile.php?id=61561885172773'
}, {
  type: 'youtube',
  href: 'https://www.youtube.com/@Upcyclers.'
}];
function FooterLink({
  href = '#',
  children
}) {
  const [h, setH] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      color: h ? 'var(--fg)' : 'var(--muted-2)',
      fontSize: 14,
      textDecoration: 'none',
      transition: 'color var(--t-fast)',
      width: 'fit-content'
    }
  }, children);
}
function SocialLink({
  type,
  href
}) {
  const icon = SOCIAL_ICONS[type];
  const [h, setH] = React.useState(false);
  if (!icon) return null;
  return /*#__PURE__*/React.createElement("a", {
    href: href,
    target: "_blank",
    rel: "noopener noreferrer",
    "aria-label": icon.label,
    title: icon.label,
    onMouseEnter: () => setH(true),
    onMouseLeave: () => setH(false),
    style: {
      width: 38,
      height: 38,
      borderRadius: '50%',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: '1px solid var(--border-strong)',
      color: h ? 'var(--btn-fg)' : 'var(--fg)',
      background: h ? 'var(--fg)' : 'transparent',
      transition: 'color var(--t-fast), background var(--t-fast), border-color var(--t-fast)',
      borderColor: h ? 'var(--fg)' : 'var(--border-strong)',
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "17",
    viewBox: "0 0 24 24",
    fill: "currentColor",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: icon.path
  })));
}
function Footer({
  logoSrc,
  logoHeight = 24,
  tagline = 'Upcycle. Resell. Repeat.',
  copyright = '© 2026 Upcyclers · A home for slow fashion',
  columns = DEFAULT_COLUMNS,
  socials = DEFAULT_SOCIALS,
  bottomLinks = [{
    label: 'Privacy'
  }, {
    label: 'Terms'
  }, {
    label: 'Accessibility'
  }],
  className,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("footer", _extends({
    className: ['uc-footer', className].filter(Boolean).join(' '),
    style: {
      borderTop: '1px solid var(--border)',
      width: '100%',
      background: 'var(--bg)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container)',
      margin: '0 auto',
      boxSizing: 'border-box',
      padding: 'var(--space-16) var(--gutter) var(--space-12)',
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'clamp(32px,5vw,72px)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 240px',
      minWidth: 0,
      maxWidth: 320
    }
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "Upcyclers",
    style: {
      height: logoHeight,
      width: 'auto',
      display: 'block',
      filter: 'var(--logo-filter,none)'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-black)',
      fontSize: 20,
      letterSpacing: '-.02em',
      color: 'var(--fg)'
    }
  }, "Upcyclers."), tagline ? /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--muted-2)',
      fontSize: 14,
      lineHeight: 1.6,
      margin: '16px 0 0',
      maxWidth: 260
    }
  }, tagline) : null, socials && socials.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 10,
      marginTop: 22
    }
  }, socials.map(s => /*#__PURE__*/React.createElement(SocialLink, {
    key: s.type,
    type: s.type,
    href: s.href
  }))) : null), columns.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '3 1 480px',
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(130px,1fr))',
      gap: 'clamp(24px,3vw,40px)'
    }
  }, columns.map(col => /*#__PURE__*/React.createElement("div", {
    key: col.title
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-extrabold)',
      fontSize: 13,
      letterSpacing: '.04em',
      textTransform: 'uppercase',
      color: 'var(--fg)',
      marginBottom: 16
    }
  }, col.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 11
    }
  }, (col.links || []).map(l => /*#__PURE__*/React.createElement(FooterLink, {
    key: l.label,
    href: l.href
  }, l.label)))))) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container)',
      margin: '0 auto',
      boxSizing: 'border-box',
      padding: 'var(--space-6) var(--gutter)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--muted-2)',
      fontSize: 13
    }
  }, copyright), bottomLinks.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 20,
      flexWrap: 'wrap'
    }
  }, bottomLinks.map(l => /*#__PURE__*/React.createElement(FooterLink, {
    key: l.label,
    href: l.href
  }, l.label))) : null)));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Header.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const IconSearch = () => /*#__PURE__*/React.createElement(__ds_scope.Icon, {
  name: "search",
  size: 19
});
const IconMoon = () => /*#__PURE__*/React.createElement(__ds_scope.Icon, {
  name: "moon",
  size: 17
});
const IconSun = () => /*#__PURE__*/React.createElement(__ds_scope.Icon, {
  name: "sun",
  size: 17
});
function IconBtn({
  label,
  onClick,
  children
}) {
  return /*#__PURE__*/React.createElement("button", {
    "aria-label": label,
    title: label,
    onClick: onClick,
    style: {
      width: 38,
      height: 38,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      background: 'transparent',
      border: 'none',
      color: 'var(--fg)',
      padding: 0
    }
  }, children);
}

/**
 * Header — the top navigation bar: hamburger + wordmark on the left,
 * icon actions + Sign in / Join on the right. Optional inline links.
 */
function Header({
  logoSrc,
  logoHref = '#',
  logoHeight = 26,
  links = [],
  theme = 'dark',
  showThemeToggle = false,
  showSearch = true,
  showSignIn = true,
  signInLabel = 'Sign in',
  joinLabel = 'Join',
  sticky = false,
  onMenu,
  onSearch,
  onToggleTheme,
  onSignIn,
  onJoin,
  className,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    className: ['uc-header', className].filter(Boolean).join(' '),
    style: {
      position: sticky ? 'sticky' : 'relative',
      top: 0,
      zIndex: 'var(--z-nav)',
      background: 'color-mix(in srgb, var(--bg) 72%, transparent)',
      backdropFilter: 'var(--blur)',
      WebkitBackdropFilter: 'var(--blur)',
      width: '100%',
      boxSizing: 'border-box',
      borderBottom: 'none',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'clamp(12px,3vw,20px)',
      padding: '18px clamp(16px, 4vw, 40px)',
      width: '100%',
      boxSizing: 'border-box'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'clamp(14px,3vw,26px)',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("button", {
    "aria-label": "Menu",
    onClick: onMenu,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 5,
      cursor: 'pointer',
      padding: 4,
      background: 'none',
      border: 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 2,
      background: 'var(--fg)',
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 2,
      background: 'var(--fg)',
      display: 'block'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 2,
      background: 'var(--fg)',
      display: 'block'
    }
  })), /*#__PURE__*/React.createElement("a", {
    href: logoHref,
    style: {
      display: 'flex',
      alignItems: 'center',
      flex: '0 0 auto'
    }
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    src: logoSrc,
    alt: "Upcyclers",
    style: {
      height: logoHeight,
      width: 'auto',
      display: 'block',
      filter: 'var(--logo-filter,none)'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-black)',
      fontSize: 22,
      letterSpacing: '-.02em',
      color: 'var(--fg)'
    }
  }, "Upcyclers.")), links.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 22,
      marginLeft: 8
    },
    className: "uc-header-links"
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.label,
    href: l.href || '#',
    style: {
      color: 'var(--muted)',
      fontWeight: 'var(--fw-semibold)',
      fontSize: 14
    }
  }, l.label))) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'clamp(8px,2vw,14px)'
    }
  }, showThemeToggle ? /*#__PURE__*/React.createElement("span", {
    className: "uc-header-hide-mobile",
    style: {
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(IconBtn, {
    label: "Toggle theme",
    onClick: onToggleTheme
  }, theme === 'dark' ? /*#__PURE__*/React.createElement(IconMoon, null) : /*#__PURE__*/React.createElement(IconSun, null))) : null, showSearch ? /*#__PURE__*/React.createElement(IconBtn, {
    label: "Search",
    onClick: onSearch
  }, /*#__PURE__*/React.createElement(IconSearch, null)) : null, showSignIn ? /*#__PURE__*/React.createElement("span", {
    className: "uc-header-hide-mobile",
    style: {
      display: 'inline-flex'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "secondary",
    size: "sm",
    onClick: onSignIn
  }, signInLabel)) : null, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm",
    onClick: onJoin
  }, joinLabel))));
}
Object.assign(__ds_scope, { Header });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Header.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Tabs — the brand's underline tab bar. Active tab carries a red underline;
 * inactive tabs are muted. Controlled (value/onChange) or uncontrolled
 * (defaultValue). Items may carry a small count `badge`.
 */
function Tabs({
  items = [],
  value,
  defaultValue,
  onChange,
  align = 'start',
  className,
  style,
  ...rest
}) {
  const first = items[0] ? items[0].id : undefined;
  const [internal, setInternal] = React.useState(defaultValue != null ? defaultValue : first);
  const active = value !== undefined ? value : internal;
  const select = id => {
    if (value === undefined) setInternal(id);
    if (onChange) onChange(id);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    className: ['uc-tabs', className].filter(Boolean).join(' '),
    style: {
      display: 'flex',
      gap: 4,
      alignItems: 'flex-end',
      justifyContent: align === 'center' ? 'center' : 'flex-start',
      borderBottom: '1px solid var(--border-strong)',
      overflowX: 'auto',
      overflowY: 'hidden',
      scrollbarWidth: 'none',
      ...style
    }
  }, rest), items.map(it => {
    const on = it.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.id,
      role: "tab",
      "aria-selected": on,
      onClick: () => select(it.id),
      style: {
        appearance: 'none',
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        fontFamily: 'var(--font-sans)',
        fontWeight: 'var(--fw-bold)',
        fontSize: 15,
        letterSpacing: '.02em',
        padding: '14px 22px',
        margin: '0 0 -1px',
        whiteSpace: 'nowrap',
        color: on ? 'var(--fg)' : 'var(--muted-2)',
        borderBottom: on ? '2px solid var(--accent)' : '2px solid transparent',
        transition: 'color var(--t-fast), border-color var(--t-fast)'
      }
    }, it.label, it.badge != null ? /*#__PURE__*/React.createElement("span", {
      style: {
        opacity: 0.6,
        fontWeight: 'var(--fw-semibold)',
        marginLeft: 6
      }
    }, "\xB7 ", it.badge) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/sections/Accordion.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Accordion — expandable +/- sections. Product details, challenge rules on
 * mobile. Bebas +/- signs; hairline dividers between rows.
 */
function Accordion({
  items = [],
  type = 'single',
  defaultOpen,
  signTone = 'accent',
  className,
  style,
  ...rest
}) {
  const initial = () => {
    if (defaultOpen != null) return Array.isArray(defaultOpen) ? defaultOpen : [defaultOpen];
    if (type === 'single' && items[0]) return [items[0].id];
    return [];
  };
  const [open, setOpen] = React.useState(initial);
  const toggle = id => {
    setOpen(cur => {
      const isOpen = cur.includes(id);
      if (type === 'multiple') return isOpen ? cur.filter(x => x !== id) : [...cur, id];
      return isOpen ? [] : [id];
    });
  };
  const signColor = signTone === 'accent' ? 'var(--accent)' : 'var(--muted-2)';
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['uc-accordion', className].filter(Boolean).join(' '),
    style: {
      borderBottom: '1px solid var(--border)',
      ...style
    }
  }, rest), items.map(it => {
    const isOpen = open.includes(it.id);
    return /*#__PURE__*/React.createElement("div", {
      key: it.id,
      style: {
        borderTop: '1px solid var(--border)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => toggle(it.id),
      "aria-expanded": isOpen,
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        width: '100%',
        appearance: 'none',
        border: 'none',
        background: 'transparent',
        cursor: 'pointer',
        textAlign: 'left',
        color: 'var(--fg)',
        fontFamily: 'var(--font-sans)',
        fontWeight: 'var(--fw-extrabold)',
        fontSize: 16,
        letterSpacing: '.02em',
        padding: '18px 2px'
      }
    }, /*#__PURE__*/React.createElement("span", null, it.label), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--font-display)',
        fontWeight: 'var(--fw-display)',
        fontSize: 26,
        color: signColor,
        lineHeight: 1
      }
    }, isOpen ? '\u2212' : '+')), isOpen ? /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 2px 22px',
        color: 'var(--muted)',
        fontSize: 14.5,
        lineHeight: 'var(--lh-body)'
      }
    }, it.content) : null);
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/sections/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/sections/Countdown.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function parseTarget(t) {
  if (t instanceof Date) return t.getTime();
  if (typeof t === 'number') return t;
  if (typeof t === 'string') {
    const d = new Date(t).getTime();
    return Number.isNaN(d) ? Date.now() : d;
  }
  return Date.now();
}
function compute(target) {
  let diff = target - Date.now();
  if (diff < 0) diff = 0;
  const p = n => String(n).padStart(2, '0');
  return {
    d: String(Math.floor(diff / 86400000)),
    h: p(Math.floor(diff / 3600000) % 24),
    m: p(Math.floor(diff / 60000) % 60),
    s: p(Math.floor(diff / 1000) % 60),
    done: diff === 0
  };
}
const SIZES = {
  sm: 'clamp(36px,9vw,56px)',
  md: 'clamp(48px,12vw,90px)',
  lg: 'var(--fs-timer)'
};

/**
 * Countdown — the brand's big Bebas Neue timer counting down to a target date.
 * Colon-separated D:H:M:S with the seconds accented in red.
 */
function Countdown({
  target,
  labels = ['DAYS', 'HOURS', 'MINUTES', 'SECONDS'],
  size = 'lg',
  accentSeconds = true,
  align = 'center',
  onComplete,
  className,
  style,
  ...rest
}) {
  const ms = React.useMemo(() => parseTarget(target), [target]);
  const [t, setT] = React.useState(() => compute(ms));
  React.useEffect(() => {
    setT(compute(ms));
    const id = setInterval(() => {
      const next = compute(ms);
      setT(next);
      if (next.done && onComplete) onComplete();
    }, 1000);
    return () => clearInterval(id);
  }, [ms]);
  const digit = SIZES[size] || SIZES.lg;
  const colon = {
    fontFamily: 'var(--font-display)',
    fontWeight: 'var(--fw-display)',
    fontSize: `calc(${digit} * .8)`,
    color: 'var(--faint)',
    lineHeight: 1.05
  };
  const cell = (value, label, accent) => /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--fw-display)',
      fontSize: digit,
      lineHeight: 'var(--lh-tight)',
      color: accent ? 'var(--accent)' : 'var(--fg)'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-sans)',
      color: 'var(--muted-2)',
      fontSize: 12,
      fontWeight: 'var(--fw-semibold)',
      letterSpacing: '.12em'
    }
  }, label));
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ['uc-countdown', className].filter(Boolean).join(' '),
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: align === 'center' ? 'center' : 'flex-start',
      gap: 'clamp(10px,4vw,44px)',
      ...style
    }
  }, rest), cell(t.d, labels[0]), /*#__PURE__*/React.createElement("div", {
    style: colon
  }, ":"), cell(t.h, labels[1]), /*#__PURE__*/React.createElement("div", {
    style: colon
  }, ":"), cell(t.m, labels[2]), /*#__PURE__*/React.createElement("div", {
    style: colon
  }, ":"), cell(t.s, labels[3], accentSeconds));
}
Object.assign(__ds_scope, { Countdown });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/sections/Countdown.jsx", error: String((e && e.message) || e) }); }

// components/sections/ChallengeHero.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * ChallengeHero — the featured quarterly-challenge hero for the homepage and
 * the reusable template for each new challenge. Decluttered editorial layout:
 * the cutout image fills the section as a bottom-right background (never cropped
 * on the sides), a theme-aware scrim keeps the left detail column readable, and
 * the content groups into calm zones — lockup, edition eyebrow, mega hashtag
 * title, lead, a compact facts strip, one dominant countdown, and actions.
 */
const CH_CSS = `
.uc-challenge-hero{position:relative;overflow:hidden;min-height:clamp(540px,56vw,760px)}
.uc-challenge-hero .uc-ch-bg{position:absolute;inset:0;z-index:0;width:100%;max-width:var(--container);margin:0 auto;padding:0 var(--gutter);box-sizing:border-box;background-repeat:no-repeat;background-position:bottom right;background-origin:content-box;background-size:contain;background-image:var(--ch-bg)}
.uc-challenge-hero .uc-ch-scrim{position:absolute;inset:0;z-index:1}
.uc-challenge-hero[data-variant="editorial"] .uc-ch-scrim{background:linear-gradient(100deg, var(--bg) 0%, var(--bg) 33%, color-mix(in srgb, var(--bg) 60%, transparent) 51%, transparent 74%)}
.uc-challenge-hero[data-variant="panel"] .uc-ch-scrim{background:linear-gradient(100deg, color-mix(in srgb, var(--bg) 72%, transparent) 0%, color-mix(in srgb, var(--bg) 28%, transparent) 46%, transparent 72%)}
.uc-challenge-hero[data-variant="spotlight"] .uc-ch-scrim{background:linear-gradient(88deg, var(--bg) 0%, color-mix(in srgb, var(--bg) 52%, transparent) 42%, transparent 72%)}
.uc-challenge-hero .uc-ch-inner{position:relative;z-index:2;max-width:var(--container);margin:0 auto;padding:clamp(30px,5vw,64px) var(--gutter);min-height:inherit;display:flex;align-items:center}
.uc-challenge-hero[data-variant="spotlight"] .uc-ch-inner{align-items:flex-start}
.uc-challenge-hero .uc-ch-text{display:flex;flex-direction:column;max-width:min(680px,100%);min-width:0}
.uc-challenge-hero[data-variant="panel"] .uc-ch-text{background:color-mix(in srgb, var(--surface-2) 84%, transparent);backdrop-filter:var(--blur);-webkit-backdrop-filter:var(--blur);border:1px solid var(--border);border-radius:var(--radius-lg);padding:clamp(26px,3vw,42px)}
.uc-challenge-hero .uc-ch-lockup{display:flex;align-items:center;gap:16px;margin-bottom:clamp(24px,4vw,38px)}
.uc-challenge-hero .uc-ch-lockup img.wm{height:26px;width:auto;display:block;filter:var(--logo-filter,none)}
.uc-challenge-hero .uc-ch-lockup .x{color:var(--muted-2);font-size:19px;line-height:1;font-weight:var(--fw-regular)}
.uc-challenge-hero .uc-ch-lockup img.partner{height:46px;width:auto;display:block}
.uc-challenge-hero .uc-ch-eyebrow{font-family:var(--font-sans);font-weight:var(--fw-bold);font-size:var(--fs-eyebrow);line-height:1;letter-spacing:var(--ls-eyebrow);text-transform:uppercase;color:#EE3124;margin-bottom:16px}
.uc-challenge-hero .uc-ch-title{font-family:var(--font-display);font-weight:400;font-size:clamp(46px,6.6vw,80px);letter-spacing:normal;line-height:1;margin:0;color:var(--fg);overflow-wrap:break-word;text-transform:uppercase}
.uc-challenge-hero .uc-ch-title .hl{color:var(--accent)}
.uc-challenge-hero .uc-ch-lead{font-family:var(--font-sans);font-weight:var(--fw-medium);font-size:var(--fs-lead);line-height:1.5;color:var(--muted);margin:18px 0 0;max-width:440px;text-wrap:pretty}
.uc-challenge-hero .uc-ch-facts{display:flex;flex-wrap:nowrap;gap:clamp(16px,2.2vw,28px);margin-top:clamp(26px,3.6vw,38px)}
.uc-challenge-hero .uc-ch-fact{display:flex;flex-direction:column;gap:7px;min-width:0}
.uc-challenge-hero .uc-ch-fact+.uc-ch-fact{border-left:1px solid var(--border-strong);padding-left:clamp(16px,2.2vw,28px)}
.uc-challenge-hero .uc-ch-fact .fl{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:10px;line-height:1;letter-spacing:.15em;text-transform:uppercase;color:var(--faint)}
.uc-challenge-hero .uc-ch-fact .fv{font-family:var(--font-display);font-weight:400;font-size:24px;line-height:1.05;letter-spacing:.02em;color:var(--fg);white-space:nowrap}
.uc-challenge-hero .uc-ch-fact .fv.prize{font-size:28px;letter-spacing:-.01em;color:var(--fg);align-self:flex-start;border-bottom:3px solid var(--uc-red);padding-bottom:4px}
.uc-challenge-hero .uc-ch-fact .fsub{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:11px;line-height:1;letter-spacing:.05em;color:var(--fg);margin-top:2px}
.uc-challenge-hero .uc-ch-timer{margin-top:clamp(14px,2vw,22px)}
.uc-challenge-hero .uc-ch-timer .tl{display:flex;flex-wrap:wrap;align-items:baseline;gap:10px;margin-bottom:13px}
.uc-challenge-hero .uc-ch-timer .tl .lab{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:12px;line-height:1;letter-spacing:.06em;text-transform:uppercase;color:var(--faint)}
.uc-challenge-hero .uc-ch-timer .tl .note{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:11px;line-height:1;letter-spacing:.14em;text-transform:uppercase;color:var(--muted-2)}
.uc-challenge-hero .uc-ch-actions{display:flex;flex-wrap:wrap;gap:12px;margin-top:clamp(26px,3.6vw,34px)}
.uc-challenge-hero .uc-ch-credits{position:absolute;right:clamp(16px,4vw,40px);bottom:clamp(14px,3vw,26px);display:flex;flex-wrap:nowrap;justify-content:flex-end;align-items:baseline;gap:clamp(8px,1.4vw,16px);line-height:1.4;z-index:3}
.uc-challenge-hero .uc-ch-credits .cr{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:11px;letter-spacing:.04em;color:rgba(255,255,255,.85);white-space:nowrap;text-shadow:0 1px 4px rgba(0,0,0,.75),0 0 2px rgba(0,0,0,.55)}
.uc-challenge-hero .uc-ch-credits .cr b{color:#fff;font-weight:var(--fw-bold)}
@media(max-width:880px){
  .uc-challenge-hero{min-height:clamp(660px,138vw,940px)}
  .uc-challenge-hero .uc-ch-bg{padding:0;background-image:var(--ch-bg-mobile);background-size:cover;background-position:top center}
  .uc-challenge-hero[data-variant] .uc-ch-scrim{background:linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,.12) 30%, rgba(0,0,0,.6) 62%, rgba(0,0,0,.97) 100%)}
  .uc-challenge-hero[data-variant] .uc-ch-inner{align-items:flex-end;justify-content:center;padding-bottom:clamp(26px,7vw,54px)}
  .uc-challenge-hero .uc-ch-text{max-width:100%;align-items:center;text-align:center;--fg:#fff;--muted:rgba(255,255,255,.82);--muted-2:rgba(255,255,255,.6);--faint:rgba(255,255,255,.58);--border-strong:rgba(255,255,255,.24)}
  .uc-challenge-hero .uc-ch-lockup{justify-content:center;margin-bottom:clamp(14px,3vw,22px)}
  .uc-challenge-hero .uc-ch-lead{margin-left:auto;margin-right:auto}
  .uc-challenge-hero[data-variant="panel"] .uc-ch-text{padding:clamp(20px,5vw,28px)}
  .uc-challenge-hero .uc-ch-facts{flex-wrap:wrap;gap:12px 16px;justify-content:center}
  .uc-challenge-hero .uc-ch-fact{align-items:center}
  .uc-challenge-hero .uc-ch-fact .fv{font-size:20px}
  .uc-challenge-hero .uc-ch-fact+.uc-ch-fact{padding-left:14px}
  .uc-challenge-hero .uc-ch-timer{display:flex;flex-direction:column;align-items:center;margin-top:12px;margin-bottom:-4px}
  .uc-challenge-hero .uc-ch-timer .tl{justify-content:center}
  .uc-challenge-hero .uc-ch-timer .uc-countdown{transform:scale(.8);transform-origin:top center}
  .uc-challenge-hero .uc-ch-actions{justify-content:center}
  .uc-challenge-hero .uc-ch-credits{left:8px;right:8px;justify-content:center;flex-wrap:nowrap;gap:8px}
  .uc-challenge-hero .uc-ch-credits .cr{font-size:clamp(8px,2.4vw,10px);letter-spacing:.02em}
}
`;
function ChallengeHero({
  logoSrc,
  logoAlt = 'Upcyclers',
  partnerSrc,
  partnerAlt = '',
  edition,
  title,
  titleAs = 'h1',
  lead,
  facts = [],
  deadline,
  deadlineLabel = 'Submit & vote until Sep 26, 2026 @ 6pm PT',
  deadlineNote,
  showCountdown = true,
  variant = 'spotlight',
  actions,
  media,
  mediaMobile,
  mediaAlt = '',
  credits = [],
  showCredits = true,
  className,
  style,
  ...rest
}) {
  const TitleTag = titleAs;
  const hasLockup = logoSrc || partnerSrc;
  const hasCredits = showCredits && credits.length > 0;
  return /*#__PURE__*/React.createElement("section", _extends({
    className: ['uc-challenge-hero', className].filter(Boolean).join(' '),
    "data-variant": variant,
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--bg)',
      borderBottom: '1px solid var(--border)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("style", {
    dangerouslySetInnerHTML: {
      __html: CH_CSS
    }
  }), media ? /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-bg",
    style: {
      '--ch-bg': `url(${media})`,
      '--ch-bg-mobile': `url(${mediaMobile || media})`
    },
    role: "img",
    "aria-label": mediaAlt
  }) : null, /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-scrim",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-inner"
  }, /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-text"
  }, hasLockup ? /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-lockup"
  }, logoSrc ? /*#__PURE__*/React.createElement("img", {
    className: "wm",
    src: logoSrc,
    alt: logoAlt
  }) : null, logoSrc && partnerSrc ? /*#__PURE__*/React.createElement("span", {
    className: "x",
    "aria-hidden": "true"
  }, "\xD7") : null, partnerSrc ? /*#__PURE__*/React.createElement("img", {
    className: "partner",
    src: partnerSrc,
    alt: partnerAlt
  }) : null) : null, edition ? /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-eyebrow"
  }, edition) : null, title ? /*#__PURE__*/React.createElement(TitleTag, {
    className: "uc-ch-title"
  }, title) : null, lead ? /*#__PURE__*/React.createElement("p", {
    className: "uc-ch-lead"
  }, lead) : null, facts.length > 0 ? /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-facts"
  }, facts.map((f, i) => /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-fact",
    key: i
  }, /*#__PURE__*/React.createElement("span", {
    className: "fl"
  }, f.label), /*#__PURE__*/React.createElement("span", {
    className: f.prize ? 'fv prize' : 'fv'
  }, f.value), f.sub ? /*#__PURE__*/React.createElement("span", {
    className: "fsub"
  }, f.sub) : null))) : null, showCountdown && deadline ? /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-timer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "tl"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lab"
  }, deadlineLabel), deadlineNote ? /*#__PURE__*/React.createElement("span", {
    className: "note"
  }, deadlineNote) : null), /*#__PURE__*/React.createElement(__ds_scope.Countdown, {
    target: deadline,
    size: "sm",
    align: "left",
    accentSeconds: false,
    style: {
      gap: 'clamp(4px,1vw,12px)'
    }
  })) : null, actions ? /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-actions"
  }, actions) : null)), hasCredits ? /*#__PURE__*/React.createElement("div", {
    className: "uc-ch-credits"
  }, credits.map((c, i) => /*#__PURE__*/React.createElement("div", {
    className: "cr",
    key: i
  }, c.role, " ", /*#__PURE__*/React.createElement("b", null, c.name)))) : null);
}
Object.assign(__ds_scope, { ChallengeHero });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/sections/ChallengeHero.jsx", error: String((e && e.message) || e) }); }

// components/sections/Hero.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Hero — the brand's centered editorial hero (homepage, challenge, drops).
 * A kicker, a mega title (Montserrat 800 ultra-tight by default, or Bebas via
 * `display`), an optional Bebas subtitle, a lead line, action buttons, and
 * room for extra rows (prize / timeline) via children. Pass `media` for a
 * full-bleed background image with a scrim.
 */
function Hero({
  eyebrow,
  brandLockup,
  title,
  titleAs = 'h1',
  display = false,
  subtitle,
  lead,
  actions,
  align = 'center',
  media,
  scrim = true,
  children,
  className,
  style,
  ...rest
}) {
  const TitleTag = titleAs;
  const centered = align === 'center';
  const titleStyle = display ? {
    fontFamily: 'var(--font-display)',
    fontWeight: 'var(--fw-display)',
    fontSize: 'var(--fs-hero)',
    letterSpacing: 'var(--ls-display)',
    lineHeight: 'var(--lh-tight)'
  } : {
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-extrabold)',
    fontSize: 'var(--fs-hero)',
    letterSpacing: 'var(--ls-hero)',
    lineHeight: 'var(--lh-mega)'
  };
  return /*#__PURE__*/React.createElement("header", _extends({
    className: ['uc-hero', className].filter(Boolean).join(' '),
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: media ? 'var(--surface)' : 'transparent',
      ...style
    }
  }, rest), media ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: media,
    alt: "",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover',
      display: 'block'
    }
  }), scrim ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'linear-gradient(180deg, rgba(10,10,10,.35), rgba(10,10,10,.82))'
    }
  }) : null) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 'var(--container-text)',
      margin: '0 auto',
      padding: 'clamp(40px,7vw,72px) var(--gutter)',
      textAlign: centered ? 'center' : 'left',
      display: 'flex',
      flexDirection: 'column',
      alignItems: centered ? 'center' : 'flex-start',
      gap: 0
    }
  }, brandLockup ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 32
    }
  }, brandLockup) : null, eyebrow ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16,
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-eyebrow)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--accent)'
    }
  }, eyebrow) : null, /*#__PURE__*/React.createElement(TitleTag, {
    style: {
      margin: 0,
      color: 'var(--fg)',
      ...titleStyle
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--fw-display)',
      fontSize: 'clamp(22px,4vw,38px)',
      letterSpacing: 'var(--ls-wide)',
      margin: '18px 0 0',
      color: 'var(--fg)'
    }
  }, subtitle) : null, lead ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-lead)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--muted)',
      margin: '16px 0 0',
      maxWidth: 640,
      textWrap: 'pretty'
    }
  }, lead) : null, actions ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 12,
      justifyContent: centered ? 'center' : 'flex-start',
      margin: '32px 0 0'
    }
  }, actions) : null, children ? /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      marginTop: 40
    }
  }, children) : null));
}
Object.assign(__ds_scope, { Hero });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/sections/Hero.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Card = __ds_scope.Card;

__ds_ns.EntryCard = __ds_scope.EntryCard;

__ds_ns.MediaCard = __ds_scope.MediaCard;

__ds_ns.PersonCard = __ds_scope.PersonCard;

__ds_ns.ProductCard = __ds_scope.ProductCard;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Gallery = __ds_scope.Gallery;

__ds_ns.AnnouncementBar = __ds_scope.AnnouncementBar;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.Header = __ds_scope.Header;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.ChallengeHero = __ds_scope.ChallengeHero;

__ds_ns.Countdown = __ds_scope.Countdown;

__ds_ns.Hero = __ds_scope.Hero;

})();
