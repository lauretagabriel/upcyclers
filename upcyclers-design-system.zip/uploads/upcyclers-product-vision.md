# Upcyclers Product Vision

## Upcyclers Product Vision

#### Web and Mobile Platform

### Vision

Upcyclers is building the community, creator ecosystem and marketplace for the global upcycling movement, bringing inspiration, materials, learning, creation and commerce into one connected platform.

### Core Journey

Discover → Buy → Learn → Create → Share → Sell → Earn → Return

The goal is to help buyers become creators and eventually sellers, while giving every user a reason to keep returning.

### North Star

Make every visit feel like something new happened.

## 1. Cross-Platform Experience

### Shared Experience

One account across web and mobile

Synced posts, listings, hearts, saves and follows

Synced messages, orders, rewards and notifications

Consistent categories, aesthetics, occasions and techniques

Clear distinction between Inspiration and For Sale

Personalized recommendations across devices

Consistent visual identity

Accessible and responsive design

### Web Experience

Designed for:

Deeper browsing and research

Creating and managing listings

Managing orders and commissions

Viewing seller analytics

Creating tutorials and patterns

Comparing products

Partner and administrative tools

### Mobile Experience

Designed for:

Fast visual discovery

Posting and listing

Shopping

Hearts, saves and comments

Messaging and notifications

Challenge participation

Virtual gifts

Livestreaming

## 2. Mobile Swipe Discovery

Shop and Inspiration remain separate so the gestures are always clear.

### Shop Feed

Every card is a product for sale.

Swipe right: Interested → Add to Cart

Swipe left: Save for Later

Swipe up: Not Interested → Next Product

Tap: Open product details

If an item requires a size, color or another option, swiping right opens a quick selection panel before adding it to the cart.

#### Safeguards

Added to Cart confirmation

Undo option

Saved for Later confirmation

First-time gesture tutorial

Visible Cart, Save and Details buttons

Clear price and For Sale label

Adding to cart does not reserve an item unless stated

### Inspiration Feed

Every card is a showcase or inspiration post.

Swipe right: Heart

Swipe left: Save

Swipe up: Next post

Tap: Open post details

Inspiration posts can also include:

Support Creator

Comment

Share

View Creator

View related products or techniques

## 3. Homepage

### Homepage Order

Hero

Limited Celebrity Drop

Quarterly Challenge: Top 10 Most Loved

Trending Now

Explore: Aesthetics | Occasions

Shop by Price

Recently Added

Most Loved

Explore Techniques

Featured Creators

Explore by Country

### Limited Celebrity Drop

Appears directly below the hero

Shows a teaser, countdown and waitlist before launch

Becomes shoppable when live

Shows results and impact afterward

Collapses when unavailable

### Quarterly Challenge

Shows the Top 10 Most Loved during voting

Shows finalists during judging

Shows the winner and runner-up afterward

Promotes the next quarterly challenge between competitions

### Explore Aesthetics and Occasions

One section with two tabs:

Aesthetics

Occasions

Each selection has two filters:

Inspiration

Shop

### Explore Techniques

Shows the nine main technique categories

Each category opens its subcategories

Selecting a technique shows related posts, tutorials, patterns, materials and creators on one page

Additional filters can be added later if needed

### Discovery Definitions

Recently Added: Newest content across Upcyclers

Most Loved: Content receiving the most hearts

Trending: Content rapidly gaining views and engagement

Top 10 Most Loved: Eligible entries ranked within the current challenge

## 4. Search and Discovery

Search products, posts, creators, techniques, tutorials and materials

Search suggestions and autocomplete

Misspelling correction

Filter by content type

Filter by category, price, aesthetic, occasion and technique

No-results recommendations

Recently viewed

Saved searches

Suggested creators

Explore by country

Personalized discovery feed

New content since the last visit

Search insights showing unmet demand

## 5. Marketplace

General categories and subcategories

Upcycled and secondhand products

Materials and supplies

Patterns and tutorials

Search, filters and sorting

Shop by Price

Shop by Aesthetic

Shop by Occasion

Shop Materials by Technique

Wishlist

Recently viewed

Saved searches

Related products

Curated collections

Limited collections

Celebrity drops

Shoppable challenge collections

Product bundles

Personalized recommendations

Livestream shopping

Gift cards and marketplace credits

International shopping and currencies

### Style Recommendations

When shoppers view or like an item, Upcyclers surfaces complementary products.

For example, when viewing a jacket, shoppers may see:

Matching bags

Shoes

Accessories

Tops and bottoms

Similar products

Options within their budget

Products matching the same aesthetic or occasion

Users can:

Complete the Look

Save the Look

Shop the Look

Adjust recommendations by price, aesthetic or occasion

Recommendations can begin with product tags and curated matching, then become increasingly personalized through AI.

## 6. Buyer Experience

Detailed product information

Photos and short videos

Size and measurements

Materials and techniques

Seller information

Shipping cost and delivery estimate

Secure checkout

Order confirmation and tracking

Purchase history

Ratings and verified-purchase reviews

Buyer protection

Returns and refunds

Dispute resolution

Seller messaging

Offers and negotiations

Price-drop alerts

Restock alerts

Saved-search alerts

Abandoned-cart reminders

Multi-seller checkout

Gift cards and marketplace credits

## 7. Seller Experience

### Seller Setup and Operations

Seller onboarding and verification

Payment and payout setup

Tax information

Clear POST versus LIST flow

Simple listing process

Listing drafts

Inventory management

Shipping settings

Order management

Shipment tracking

Seller policies

Payout history

Vacation mode

Bulk listing tools

International selling

### Seller Profile and Storefront

Seller bio and portfolio

Products for sale

Showcase posts

Ratings and reviews

Techniques and specialties

Commission availability

Typical commission range

Workshops, patterns and tutorials

Environmental impact

### Creator Badges

Challenge Winner

Challenge Runner-Up

Special Awards

Verified Seller

Rising Upcycler

Educator

Impact Leader

Impact Leader recognizes sellers with the highest estimated environmental savings.

### Seller Dashboard

#### Listing Performance

Search impressions

Product views

Hearts and saves

Add-to-cart activity

Offers received and accepted

Conversion rate

Time to sell

Sell-through rate

Aging inventory

Best-performing listings

Listings that need improvement

#### Sales and Profit

Orders

Revenue

Estimated profit

Net earnings

Average order value

Best-performing products

Best-performing price ranges

Sales over time

Repeat buyers

Returns, refunds and cancellations

#### Audience and Traffic

Traffic sources

Buyer locations

New versus returning visitors

Search terms leading to listings

Followers gained

Email and social-sharing traffic

#### Marketplace Insights

Products currently selling

Trending aesthetics and occasions

In-demand fabrics and materials

Popular techniques

High-performing sizes, colors and price ranges

Seasonal trends

Demand by location

Products buyers want but cannot find

Comparison with similar listings

Marketplace insights use anonymous, aggregated data.

#### Additional Revenue

Commission requests and conversion

Tutorial and pattern sales

Virtual gifts and tips

Livestream views, engagement and sales

#### Seller Recommendations

What to create or list next

Recommended price changes

Listings to refresh

Missing product information

Suggested categories and tags

Inventory alerts

Monthly performance summaries

Personalized business recommendations

### Cost and Profit Calculator

Sellers enter:

Material costs

Labor hours and rate

Packaging

Shipping

Platform fees

Desired profit margin

Upcyclers calculates:

Minimum recommended price

Suggested selling price

Estimated fees

Net earnings

Expected profit margin

### Dynamic Pricing

Pricing suggestions use:

Similar active listings

Previous transactions

Recently sold comparable products

Views, saves and demand

Materials and labor

Condition

Uniqueness and craftsmanship

Seller history and reviews

The seller receives a suggested price range, competitive comparison and price-change recommendations. The seller always controls the final price.

### AI Listing Assistant

AI can:

Detect the item type from photos

Suggest categories and subcategories

Identify materials, colors and techniques

Recommend aesthetics and occasions

Generate a title and description

Suggest keywords and tags

Prompt for missing measurements

Recommend shipping information

Suggest a price range

Flag missing information

### Listing Optimization

Cover-photo recommendations

Image-quality checks

Title and description improvements

Category and tag suggestions

Missing measurement reminders

Pricing recommendations

Relevant aesthetics and occasions

Inactive-listing refresh suggestions

Listing Health Score

### Seller Growth Tools

Discount codes

Promoted listings

Premium seller plan

Paid patterns and tutorials

Livestream shopping

Demand and trend alerts

Suggestions for what to create next

Photo background cleanup

Duplicate-listing detection

Shipping and packaging recommendations

## 8. Community

Hearts

Comments and replies on posts, tutorials and seller products

Product questions and seller responses

Sharing and mentions

Follow creators

Community feed

Save inspiration

Direct messaging

Creator Q&As

Progress updates

Livestream demonstrations

Collaborative projects

Community and regional groups

### Product Comments

Buyers ask questions before purchasing

Sellers respond publicly

Sellers pin helpful responses

Users receive reply notifications

Comments can be reported or moderated

Comments and reviews remain separate:

Comments: Questions and open conversation

Reviews: Verified buyer feedback after purchase

### Forums and Knowledge Hub

Organize discussions by topic

Turn helpful comments into discussions

Search questions and answers

Follow topics

Highlight helpful answers

Connect discussions to tutorials, products and materials

Use AI to summarize conversations

Turn recurring questions into guides

## 9. Loyalty, Growth and Retention

Both buyers and sellers receive rewards for returning and participating.

### Buyer Rewards

Purchases and repeat purchases

Referrals

Following creators

Attending workshops

Supporting creators with virtual gifts

Meaningful community participation

### Seller Rewards

Completing the first listing

Consistent listing activity

Successful sales

Reliable fulfillment

Positive buyer reviews

Challenge participation

Tutorials and workshops

Environmental-impact milestones

### Reward Options

Marketplace credits

Discounted fees

Free or discounted promoted listings

Early access to celebrity drops

Workshop discounts

Loyalty badges

Profile recognition

Exclusive creator opportunities

### First-Post Experience

Invite users to post after signup

Explain POST versus LIST

Simplify uploading

Save drafts

Select an aesthetic, occasion and technique

Join an eligible challenge

Appear in Recently Added

Celebrate the first post

### Notifications and Return Loops

Views and hearts

Comments and replies

Follows and messages

Offers, orders and shipping

Sales and reviews

Virtual gifts

Commission requests

Challenge rankings

Livestream reminders

Celebrity drops

Saved-item updates

New content from followed creators

Weekly community digest

## 10. Learning

Explore nine main technique categories

Browse technique subcategories

Discover related posts and creators

Access tutorials, tips and patterns

Find relevant materials and tools

Save learning content

Create project collections

Track project progress

Join online and in-person workshops

Watch workshop replays

Take creator-led courses

Earn learning badges

Access mentorship

Receive AI project guidance

## 11. Upcycling Commissions

### Post a Project

Upload the piece

Describe the desired transformation

Add inspiration

Select an aesthetic and technique

Set a budget and deadline

Add location and shipping details

Make the request public or invitation-only

### Find a Creator

Match by:

Budget

Skills

Style

Portfolio

Location

Availability

Reviews

Typical pricing

### Manage the Project

Creator proposals

Proposal comparison

Messaging

Project agreement

Deposit and milestone payments

Progress updates

Revision limits

Final approval

Shipping and payout

Reviews and dispute protection

AI matching and budget guidance

## 12. Creator Tips and Gamification

Users can support creators even when a post is not for sale or the product is beyond their budget.

### Virtual Gifts

Virtual gifts can be sent on:

Showcase posts

Products

Tutorials

Challenge entries

Creator profiles

Livestreams

Gift values can vary. Examples include:

🌸 Flower — $1

💐 Bouquet — $5

### Gift Features

One-tap gifting

Animated reactions

Public or private gifts

Optional messages

Gift notifications

Creator thank-you replies

Creator earnings balance

Payout history

Gift bundles

Supporter and creator milestones

## 13. Livestream Shopping

Scheduled livestreams

Follower reminders

Product showcases

Technique demonstrations

Live comments and questions

Pinned products

In-stream purchasing

Virtual gifts

Viewer and engagement counts

Livestream replays

Products linked in replays

## 14. Quarterly Challenges

Four global challenges each year

Dedicated challenge pages

Entry submission and validation

Community voting

Real-time Top 10 Most Loved

One finalist position per creator

Countdown, rules and prizes

Judges and judging criteria

Digital scorecards

Winner and runner-up

Challenge archive

Creator badges

Sponsored challenges

Shoppable challenge collections

Challenge analytics

## 15. Celebrity Upcycled Drops

Celebrity-donated garments

Selected creators transform the pieces

Dedicated drop page

Celebrity, garment and charity stories

Before-and-after content

Countdown and waitlist

Limited inventory

Creator credits

Authenticity certificates

Charity contribution

Fundraising and environmental impact

Livestream reveal or auction

Behind-the-scenes content

Recurring drops

## 16. AI Creation and Personalization

### AI Creation Tool

User enters a prompt.

AI generates an upcycled design.

User saves or revises it.

AI identifies the materials, tools and techniques.

Upcyclers surfaces relevant products, learning and creators.

#### Actions

Make It

Shop the Materials

Learn the Technique

Commission It

Shop Similar

### AI Personalization

AI learns from views, hearts, saves, purchases, aesthetics, occasions, budgets and followed creators.

It recommends:

Complementary products

Complete outfits

Similar products

Materials and tools

Tutorials and patterns

Creators who can make or customize the look

### AI Transparency

Identify AI-generated suggestions

Let users edit AI-generated content

Keep sellers in control of pricing

Explain recommendations

Protect uploaded images and user data

Establish ownership rules for AI-generated designs

## 17. Impact and Sustainability

Materials reused

Waste diverted

Water saved

Estimated emissions avoided

Product impact estimates

Seller impact totals

Platform impact dashboard

Impact Leader recognition

Sustainability badges

Partner reports

QR product stories

Lifecycle reporting

Transparent impact methodology

Verified versus estimated impact

## 18. B2B and Material Exchange

Brand and organization accounts

Deadstock and excess-material listings

Bulk-material opportunities

Material requests

Local material matching

Creator calls

Paid creative briefs

Brand-sponsored commissions

Sponsored challenges

Partner dashboards

Material transformation tracking

Impact reporting

School and nonprofit accounts

## 19. Trust, Payments and Support

Seller verification

Secure payments and payouts

Platform fees

Returns, refunds and chargebacks

Shipping labels and tracking

Lost or damaged package support

Seller tax documentation

Virtual-gift payouts

Commission milestone payments

Charity-payment tracking

Fraud protection

Content and intellectual-property reporting

Sustainability-claim review

Challenge-voting protection

Livestream and forum moderation

Help Center

Buyer and seller support

## 20. Platform Operations

Admin dashboard

User, listing, order and payout management

Challenge and judging management

Celebrity-drop management

Commission management

Virtual-gift management

Content moderation

Analytics and reporting

Security and backups

Site reliability

Privacy and accessibility

Localization

International expansion
