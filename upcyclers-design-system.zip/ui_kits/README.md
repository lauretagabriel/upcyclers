# UI kit — Upcyclers website

High-fidelity, click-through recreations of the three public Upcyclers surfaces, built by composing the design-system components (never re-implementing them). Each screen is one `index.html` (loads `../../styles.css` + `../../_ds_bundle.js` + React/Babel) plus one screen `.jsx`.

## Screens
- **homepage/** — Marketing home: announcement bar, sticky header (with dark/light toggle), the **ChallengeHero** (spotlight), an editorial **Celebrity Drop** band, the Quarterly Challenge **Top 10 Most Loved** grid (10 cards, max 5/row), **Community** (feature tile + explore list + technique chips), **Marketplace** (two tiles), **Recently Uploaded** (auto-scroll marquee), **Most Loved** (masonry), **Discover by Vibe & Moment**, **Featured Upcyclers** (auto-scroll marquee), **Hall of Fame** plaque, and the shared footer.
- **challenge/** — `ChallengePage.jsx`. The `#thriftflip` event page: co-brand lockup hero, prize + timeline rows, big countdown, "Everything you need to know" tabs (How It Works / Judging Criteria / Judges / Contest Rules), Top-10 grid.
- **product/** — `ProductPage.jsx`. Marketplace product details: image gallery → **Gallery lightbox**, purchase panel with accordions, Story, Impact stats, Measurements + Shipping, Reviews / Comments tabs.

## Interactions to try
- Click any product / entry / gallery image → the **Gallery** lightbox opens (arrows, thumbnail rail, X, Esc / ←/→ keys).
- Toggle the theme (sun/moon in the header on homepage + product) → the whole page swaps dark ⇄ light.
- Hover a marquee (Recently Uploaded, Featured Upcyclers) to pause its auto-scroll.
- The footer social icons (Instagram, TikTok, X, Facebook, YouTube) open in a new tab.
- Switch tabs (Explore, challenge details, Reviews/Comments); save hearts on product cards.
- Cross-navigation: the announcement bar, footer, and "Back" link move between the three pages.

## Notes
- Imagery uses Unsplash fashion photography (`images.unsplash.com/...`) cycled across grids, feeds and the gallery. Swap in real media per listing in production.
- Copy is lifted from the provided product + challenge sources; challenge dates/prizes match the `#thriftflip 2026` brief.
