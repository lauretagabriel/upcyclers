# Product page — UI kit

Marketplace product details page (the Aberdeen Jacket). See `../README.md`.

- **Entry:** `index.html` → `ProductPage.jsx`
- **Composes:** `Header`, `AnnouncementBar`, `Tabs`, `Accordion`, `Avatar`, `Badge`, `Tag`, `Stat`, `Button`, `Eyebrow`, `Gallery`, `Footer`.
- **Blocks (faithful to source):** image gallery + thumbnails → lightbox, purchase panel (seller, price, add-to-cart / save, Details/Materials/Techniques accordion), Story, Impact stats, Measurements, Shipping & Returns, Reviews (summary + distribution + composer + list) / Comments (with seller replies) tabs.
- **Interactive:** thumbnail → main image, click main → **Gallery** lightbox (keyboard nav), dark/light toggle, save, review/comment tabs.
