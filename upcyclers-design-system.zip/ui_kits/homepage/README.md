# Homepage — UI kit

Upcyclers marketing homepage recreation. See `../README.md` for the shared kit notes.

- **Entry:** `index.html` → `Homepage.jsx`
- **Composes:** `Header`, `AnnouncementBar`, `Hero`, `Countdown`, `Tabs`, `Tag`, `Eyebrow`, `ProductCard`, `EntryCard`, `PersonCard`, `MediaCard`, `Badge`, `Button`, `Gallery`, `Footer`.
- **Sections (vision-doc order):** hero → Limited Celebrity Drop → Explore (Aesthetics/Occasions) → Quarterly Challenge Top 10 → Trending Now → Featured Creators → footer.
- **Interactive:** dark/light toggle, gallery lightbox from cards, save hearts, explore tabs, links to the challenge page.
