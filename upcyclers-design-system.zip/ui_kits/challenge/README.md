# Challenge page — UI kit

The `#thriftflip` Global Upcycling Challenge 2026 page (Upcyclers × The Salvation Army Thrift Stores). See `../README.md`.

- **Entry:** `index.html` → `ChallengePage.jsx`
- **Composes:** `Header`, `AnnouncementBar`, `Hero` (co-brand lockup + prize/timeline children), `Countdown`, `Tabs`, `Stat`, `EntryCard`, `PersonCard`, `Button`, `Eyebrow`, `Gallery`, `Footer`.
- **Faithful to source:** hero copy, $750/$100 prizes, Jul 1–Sep 26 timeline, four judging-criteria weights, three judges, five contest-rule blocks, Top-10 grid.
- **Interactive:** detail tabs (How It Works / Judging Criteria / Judges / Contest Rules), live countdown, gallery lightbox, back to homepage.
