import React from 'react';
import { Icon } from '../core/Icon.jsx';

/**
 * AnnouncementBar — thin strip above the header for a running message
 * (e.g. a challenge countdown) with an optional trailing link.
 */
export function AnnouncementBar({ children, action, align = 'center', tone = 'default', className, style, ...rest }) {
  const accent = tone === 'accent';
  return (
    <div
      className={['uc-announcement', className].filter(Boolean).join(' ')}
      style={{
        display: 'flex', flexWrap: 'wrap', alignItems: 'center',
        justifyContent: align === 'between' ? 'space-between' : 'center',
        gap: '6px 18px', padding: '14px var(--gutter)', boxSizing: 'border-box',
        fontFamily: 'var(--font-sans)', fontSize: 13, letterSpacing: '.2px',
        background: accent ? 'var(--accent)' : 'var(--bg)',
        color: accent ? '#fff' : 'var(--muted-2)',
        borderBottom: accent ? 'none' : '1px solid var(--border)',
        ...style,
      }}
      {...rest}
    >
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'baseline', gap: 4 }}>{children}</div>
      {action ? (
        <a href={action.href || '#'} onClick={action.onClick} style={{
          color: accent ? '#fff' : 'var(--fg)', fontWeight: 'var(--fw-bold)',
          display: 'inline-flex', alignItems: 'center', gap: 6,
        }}>
          {action.label}<Icon name="arrow-right" size={15} />
        </a>
      ) : null}
    </div>
  );
}
