**Header** — the global top nav: hamburger + wordmark left, icon actions + Sign in / Join right. Composes `Button`.

```jsx
<Header logoSrc="assets/upcyclers-white.png" showThemeToggle theme={theme} onToggleTheme={flip} />
```

Pass `logoSrc` for the real wordmark (falls back to "Upcyclers." text). `sticky` pins it. `links` adds inline desktop nav. Actions are wired via `onMenu/onSearch/onSignIn/onJoin`.
