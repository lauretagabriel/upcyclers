**Tabs** — underline tab bar; the active tab carries the red underline. Controlled or uncontrolled; drives content the consumer renders.

```jsx
<Tabs
  items={[{id:'reviews',label:'Reviews',badge:24},{id:'comments',label:'Comments',badge:3}]}
  value={tab} onChange={setTab}
/>
```

`align="center"` centers the row (used on the challenge page). Scrolls horizontally on narrow screens.
