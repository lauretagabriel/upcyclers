import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { Button } from '../core/Button.jsx';

const IconSearch = () => <Icon name="search" size={19} />;
const IconMoon = () => <Icon name="moon" size={17} />;
const IconSun = () => <Icon name="sun" size={17} />;

function IconBtn({ label, onClick, children }) {
  return (
    <button aria-label={label} title={label} onClick={onClick} style={{
      width: 38, height: 38, borderRadius: '50%', display: 'flex', alignItems: 'center',
      justifyContent: 'center', cursor: 'pointer', background: 'transparent',
      border: 'none', color: 'var(--fg)', padding: 0,
    }}>{children}</button>
  );
}

/**
 * Header — the top navigation bar: hamburger + wordmark on the left,
 * icon actions + Sign in / Join on the right. Optional inline links.
 */
export function Header({
  logoSrc,
  logoHref = '#',
  logoHeight = 26,
  links = [],
  theme = 'dark',
  showThemeToggle = false,
  showSearch = true,
  showSignIn = true,
  signInLabel = 'Sign in',
  joinLabel = 'Join',
  sticky = false,
  onMenu,
  onSearch,
  onToggleTheme,
  onSignIn,
  onJoin,
  className,
  style,
  ...rest
}) {
  return (
    <nav
      className={['uc-header', className].filter(Boolean).join(' ')}
      style={{
        position: sticky ? 'sticky' : 'relative', top: 0, zIndex: 'var(--z-nav)',
        background: 'color-mix(in srgb, var(--bg) 72%, transparent)',
        backdropFilter: 'var(--blur)', WebkitBackdropFilter: 'var(--blur)',
        width: '100%', boxSizing: 'border-box',
        borderBottom: 'none', ...style,
      }}
      {...rest}
    >
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        gap: 'clamp(12px,3vw,20px)', padding: '18px clamp(16px, 4vw, 40px)',
        width: '100%', boxSizing: 'border-box',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'clamp(14px,3vw,26px)', minWidth: 0 }}>
          <button aria-label="Menu" onClick={onMenu} style={{
            display: 'flex', flexDirection: 'column', gap: 5, cursor: 'pointer',
            padding: 4, background: 'none', border: 'none',
          }}>
            <span style={{ width: 26, height: 2, background: 'var(--fg)', display: 'block' }} />
            <span style={{ width: 26, height: 2, background: 'var(--fg)', display: 'block' }} />
            <span style={{ width: 18, height: 2, background: 'var(--fg)', display: 'block' }} />
          </button>
          <a href={logoHref} style={{ display: 'flex', alignItems: 'center', flex: '0 0 auto' }}>
            {logoSrc ? (
              <img src={logoSrc} alt="Upcyclers" style={{ height: logoHeight, width: 'auto', display: 'block', filter: 'var(--logo-filter,none)' }} />
            ) : (
              <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-black)', fontSize: 22, letterSpacing: '-.02em', color: 'var(--fg)' }}>Upcyclers.</span>
            )}
          </a>
          {links.length > 0 ? (
            <div style={{ display: 'flex', gap: 22, marginLeft: 8 }} className="uc-header-links">
              {links.map((l) => (
                <a key={l.label} href={l.href || '#'} style={{ color: 'var(--muted)', fontWeight: 'var(--fw-semibold)', fontSize: 14 }}>{l.label}</a>
              ))}
            </div>
          ) : null}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 'clamp(8px,2vw,14px)' }}>
          {showThemeToggle ? (
            <span className="uc-header-hide-mobile" style={{ display: 'inline-flex' }}>
              <IconBtn label="Toggle theme" onClick={onToggleTheme}>{theme === 'dark' ? <IconMoon /> : <IconSun />}</IconBtn>
            </span>
          ) : null}
          {showSearch ? <IconBtn label="Search" onClick={onSearch}><IconSearch /></IconBtn> : null}
          {showSignIn ? <span className="uc-header-hide-mobile" style={{ display: 'inline-flex' }}><Button variant="secondary" size="sm" onClick={onSignIn}>{signInLabel}</Button></span> : null}
          <Button variant="primary" size="sm" onClick={onJoin}>{joinLabel}</Button>
        </div>
      </div>
    </nav>
  );
}
