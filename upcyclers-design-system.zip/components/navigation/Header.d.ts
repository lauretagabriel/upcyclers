import type { CSSProperties } from 'react';

export interface HeaderLink { label: string; href?: string; }

/**
 * Global top navigation bar.
 * @startingPoint section="Navigation" subtitle="Top nav: hamburger, wordmark, Sign in / Join" viewport="1200x92"
 */
export interface HeaderProps {
  /** Wordmark image URL. Falls back to the "Upcyclers." text mark. */
  logoSrc?: string;
  logoHref?: string;
  logoHeight?: number;
  /** Optional inline desktop nav links. */
  links?: HeaderLink[];
  /** Controls which toggle glyph shows. @default 'dark' */
  theme?: 'dark' | 'light';
  /** @default false */
  showThemeToggle?: boolean;
  /** @default true */
  showSearch?: boolean;
  /** @default true */
  showSignIn?: boolean;
  signInLabel?: string;
  joinLabel?: string;
  /** Stick to the top with a hairline border. @default false */
  sticky?: boolean;
  onMenu?: () => void;
  onSearch?: () => void;
  onToggleTheme?: () => void;
  onSignIn?: () => void;
  onJoin?: () => void;
  className?: string;
  style?: CSSProperties;
}

export function Header(props: HeaderProps): JSX.Element;
