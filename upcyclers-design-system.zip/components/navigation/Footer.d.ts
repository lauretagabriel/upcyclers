import type { CSSProperties } from 'react';

export interface FooterLink { label: string; href?: string; }
export interface FooterColumn { title: string; links: FooterLink[]; }
export type SocialType = 'instagram' | 'tiktok' | 'x' | 'facebook' | 'youtube';
export interface FooterSocial { type: SocialType; href: string; }

export interface FooterProps {
  logoSrc?: string;
  logoHeight?: number;
  /** Short brand line under the logo. @default 'Upcycle. Resell. Repeat.' */
  tagline?: string;
  /** @default '© 2026 Upcyclers · A home for slow fashion' */
  copyright?: string;
  /** Sitemap columns. Defaults to Challenge / Community / Marketplace / Upcyclers. */
  columns?: FooterColumn[];
  /** Social icon links (open in a new tab). Defaults to the five Upcyclers accounts. */
  socials?: FooterSocial[];
  /** Legal links in the bottom bar. @default Privacy / Terms / Accessibility */
  bottomLinks?: FooterLink[];
  className?: string;
  style?: CSSProperties;
}

/** Site footer — brand + tagline + social row, sitemap columns, and a bottom
 *  copyright bar. All content has brand defaults for a consistent footer across pages. */
export function Footer(props: FooterProps): JSX.Element;
