import React from 'react';

/**
 * Tabs — the brand's underline tab bar. Active tab carries a red underline;
 * inactive tabs are muted. Controlled (value/onChange) or uncontrolled
 * (defaultValue). Items may carry a small count `badge`.
 */
export function Tabs({ items = [], value, defaultValue, onChange, align = 'start', className, style, ...rest }) {
  const first = items[0] ? items[0].id : undefined;
  const [internal, setInternal] = React.useState(defaultValue != null ? defaultValue : first);
  const active = value !== undefined ? value : internal;

  const select = (id) => {
    if (value === undefined) setInternal(id);
    if (onChange) onChange(id);
  };

  return (
    <div
      role="tablist"
      className={['uc-tabs', className].filter(Boolean).join(' ')}
      style={{
        display: 'flex', gap: 4, alignItems: 'flex-end',
        justifyContent: align === 'center' ? 'center' : 'flex-start',
        borderBottom: '1px solid var(--border-strong)',
        overflowX: 'auto', overflowY: 'hidden', scrollbarWidth: 'none', ...style,
      }}
      {...rest}
    >
      {items.map((it) => {
        const on = it.id === active;
        return (
          <button
            key={it.id}
            role="tab"
            aria-selected={on}
            onClick={() => select(it.id)}
            style={{
              appearance: 'none', border: 'none', background: 'transparent', cursor: 'pointer',
              fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-bold)', fontSize: 15,
              letterSpacing: '.02em', padding: '14px 22px', margin: '0 0 -1px', whiteSpace: 'nowrap',
              color: on ? 'var(--fg)' : 'var(--muted-2)',
              borderBottom: on ? '2px solid var(--accent)' : '2px solid transparent',
              transition: 'color var(--t-fast), border-color var(--t-fast)',
            }}
          >
            {it.label}
            {it.badge != null ? <span style={{ opacity: 0.6, fontWeight: 'var(--fw-semibold)', marginLeft: 6 }}>· {it.badge}</span> : null}
          </button>
        );
      })}
    </div>
  );
}
