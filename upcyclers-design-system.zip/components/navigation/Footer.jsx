import React from 'react';

/**
 * Footer — the shared site footer: brand lockup + tagline + social row on the
 * left, a sitemap grid on the right, and a hairline bottom bar with the
 * copyright and legal links. Columns, socials, tagline and copyright all have
 * brand defaults, so `<Footer logoSrc={LOGO} />` renders the full, consistent
 * footer used across every page. Pass props to override any part.
 */

// Brand marks (Simple Icons, CC0). 24×24, single fill path.
const SOCIAL_ICONS = {
  instagram: { label: 'Instagram', path: 'M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z' },
  tiktok: { label: 'TikTok', path: 'M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z' },
  x: { label: 'X', path: 'M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z' },
  facebook: { label: 'Facebook', path: 'M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z' },
  youtube: { label: 'YouTube', path: 'M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z' },
};

const DEFAULT_COLUMNS = [
  { title: 'Challenge', links: [{ label: 'Current challenge' }, { label: 'Past challenges' }, { label: 'Rules' }, { label: 'Hall of Fame' }] },
  { title: 'Community', links: [{ label: 'Explore' }, { label: 'Techniques' }, { label: 'Featured creators' }, { label: 'Countries' }] },
  { title: 'Marketplace', links: [{ label: 'Reworked Vintage' }, { label: 'Secondhand' }, { label: 'Deadstock' }, { label: 'Sell' }] },
  { title: 'Upcyclers', links: [{ label: 'About' }, { label: 'Sustainability' }, { label: 'Help' }, { label: 'Contact' }] },
];

const DEFAULT_SOCIALS = [
  { type: 'instagram', href: 'https://www.instagram.com/upcyclers_/' },
  { type: 'tiktok', href: 'https://www.tiktok.com/@upcyclers_' },
  { type: 'x', href: 'https://x.com/Upcyclers_' },
  { type: 'facebook', href: 'https://www.facebook.com/profile.php?id=61561885172773' },
  { type: 'youtube', href: 'https://www.youtube.com/@Upcyclers.' },
];

function FooterLink({ href = '#', children }) {
  const [h, setH] = React.useState(false);
  return (
    <a href={href} onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{ color: h ? 'var(--fg)' : 'var(--muted-2)', fontSize: 14, textDecoration: 'none', transition: 'color var(--t-fast)', width: 'fit-content' }}>{children}</a>
  );
}

function SocialLink({ type, href }) {
  const icon = SOCIAL_ICONS[type];
  const [h, setH] = React.useState(false);
  if (!icon) return null;
  return (
    <a href={href} target="_blank" rel="noopener noreferrer" aria-label={icon.label} title={icon.label}
      onMouseEnter={() => setH(true)} onMouseLeave={() => setH(false)}
      style={{
        width: 38, height: 38, borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        border: '1px solid var(--border-strong)', color: h ? 'var(--btn-fg)' : 'var(--fg)',
        background: h ? 'var(--fg)' : 'transparent', transition: 'color var(--t-fast), background var(--t-fast), border-color var(--t-fast)',
        borderColor: h ? 'var(--fg)' : 'var(--border-strong)', textDecoration: 'none',
      }}>
      <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d={icon.path} /></svg>
    </a>
  );
}

export function Footer({
  logoSrc,
  logoHeight = 24,
  tagline = 'Upcycle. Resell. Repeat.',
  copyright = '© 2026 Upcyclers · A home for slow fashion',
  columns = DEFAULT_COLUMNS,
  socials = DEFAULT_SOCIALS,
  bottomLinks = [{ label: 'Privacy' }, { label: 'Terms' }, { label: 'Accessibility' }],
  className,
  style,
  ...rest
}) {
  return (
    <footer
      className={['uc-footer', className].filter(Boolean).join(' ')}
      style={{ borderTop: '1px solid var(--border)', width: '100%', background: 'var(--bg)', ...style }}
      {...rest}
    >
      <div style={{
        maxWidth: 'var(--container)', margin: '0 auto', boxSizing: 'border-box',
        padding: 'var(--space-16) var(--gutter) var(--space-12)',
        display: 'flex', flexWrap: 'wrap', gap: 'clamp(32px,5vw,72px)',
      }}>
        {/* Brand */}
        <div style={{ flex: '1 1 240px', minWidth: 0, maxWidth: 320 }}>
          {logoSrc ? (
            <img src={logoSrc} alt="Upcyclers" style={{ height: logoHeight, width: 'auto', display: 'block', filter: 'var(--logo-filter,none)' }} />
          ) : (
            <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-black)', fontSize: 20, letterSpacing: '-.02em', color: 'var(--fg)' }}>Upcyclers.</span>
          )}
          {tagline ? <p style={{ color: 'var(--muted-2)', fontSize: 14, lineHeight: 1.6, margin: '16px 0 0', maxWidth: 260 }}>{tagline}</p> : null}
          {socials && socials.length > 0 ? (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10, marginTop: 22 }}>
              {socials.map((s) => <SocialLink key={s.type} type={s.type} href={s.href} />)}
            </div>
          ) : null}
        </div>
        {/* Sitemap */}
        {columns.length > 0 ? (
          <div style={{ flex: '3 1 480px', display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(130px,1fr))', gap: 'clamp(24px,3vw,40px)' }}>
            {columns.map((col) => (
              <div key={col.title}>
                <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-extrabold)', fontSize: 13, letterSpacing: '.04em', textTransform: 'uppercase', color: 'var(--fg)', marginBottom: 16 }}>{col.title}</div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
                  {(col.links || []).map((l) => (
                    <FooterLink key={l.label} href={l.href}>{l.label}</FooterLink>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : null}
      </div>
      {/* Bottom bar */}
      <div style={{ borderTop: '1px solid var(--border)' }}>
        <div style={{
          maxWidth: 'var(--container)', margin: '0 auto', boxSizing: 'border-box',
          padding: 'var(--space-6) var(--gutter)',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 14,
        }}>
          <div style={{ color: 'var(--muted-2)', fontSize: 13 }}>{copyright}</div>
          {bottomLinks.length > 0 ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 20, flexWrap: 'wrap' }}>
              {bottomLinks.map((l) => (
                <FooterLink key={l.label} href={l.href}>{l.label}</FooterLink>
              ))}
            </div>
          ) : null}
        </div>
      </div>
    </footer>
  );
}
