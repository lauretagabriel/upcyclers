import type { ReactNode, CSSProperties } from 'react';

export interface AnnouncementAction { label: string; href?: string; onClick?: () => void; }

export interface AnnouncementBarProps {
  children?: ReactNode;
  /** Trailing link. */
  action?: AnnouncementAction;
  /** center = message centered; between = message left, link right. @default 'center' */
  align?: 'center' | 'between';
  /** Solid red bar vs. hairline-bottom default. @default 'default' */
  tone?: 'default' | 'accent';
  className?: string;
  style?: CSSProperties;
}

/** Thin announcement / countdown strip above the header. */
export function AnnouncementBar(props: AnnouncementBarProps): JSX.Element;
