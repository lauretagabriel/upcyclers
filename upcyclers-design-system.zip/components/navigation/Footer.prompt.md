**Footer** — shared site footer: brand + tagline + social row, a sitemap grid, and a bottom copyright bar. All content has brand defaults, so a bare `<Footer />` renders the full, consistent footer used across every page (homepage, product, challenge). Social links (Instagram, TikTok, X, Facebook, YouTube) open in a new tab.

```jsx
<Footer logoSrc="assets/upcyclers-white.png" />
<Footer
  tagline="Upcycle. Resell. Repeat."
  columns={[{title:'Challenge', links:[{label:'Rules'}]}]}
  socials={[{type:'instagram', href:'https://instagram.com/upcyclers_'}]}
  bottomLinks={[{label:'Privacy'}]} />
```
