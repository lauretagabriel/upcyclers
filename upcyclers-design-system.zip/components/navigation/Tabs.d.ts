import type { CSSProperties } from 'react';

export interface TabItem {
  id: string;
  label: string;
  /** Optional count shown after the label (e.g. "· 24"). */
  badge?: string | number;
}

/**
 * Underline tab bar with a red active indicator.
 * @startingPoint section="Navigation" subtitle="Underline tab bar with red active indicator" viewport="700x120"
 */
export interface TabsProps {
  items: TabItem[];
  /** Controlled active id. */
  value?: string;
  /** Uncontrolled initial id. */
  defaultValue?: string;
  onChange?: (id: string) => void;
  /** @default 'start' */
  align?: 'start' | 'center';
  className?: string;
  style?: CSSProperties;
}

export function Tabs(props: TabsProps): JSX.Element;
