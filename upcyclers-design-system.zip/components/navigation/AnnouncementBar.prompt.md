**AnnouncementBar** — thin strip above the header for a running message (challenge countdown, drop teaser) with an optional link.

```jsx
<AnnouncementBar align="between" action={{label:'View all entries'}}>
  <span style={{fontWeight:600}}>#thriftflip challenge ends in</span>
  <strong>74</strong> days
</AnnouncementBar>
```

`tone="accent"` makes it a solid red bar.
