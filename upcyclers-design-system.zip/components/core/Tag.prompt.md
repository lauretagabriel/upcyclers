**Tag** — pill chip for materials, categories and selectable filters.

```jsx
<Tag>Denim</Tag>
<Tag variant="solid">Upcycled</Tag>
<Tag selected onClick={pick}>Outerwear</Tag>
```

`variant`: default (chip fill) · outline · solid (red wash). Pass `onClick` to make it an interactive filter chip; `selected` inverts it.
