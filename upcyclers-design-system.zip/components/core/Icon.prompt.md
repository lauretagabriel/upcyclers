**Icon** — the single source for every UI glyph. Renders an official [Lucide](https://lucide.dev) icon by name, loaded from the pinned CDN (`window.lucide` UMD build) and drawn into an `<svg>` the component controls (size / stroke / fill / color). **Any** valid Lucide name works (kebab-case) — browse names at [lucide.dev/icons](https://lucide.dev/icons). Use this for all interface affordances — never inline ad-hoc SVG or emoji for an icon.

```jsx
<Icon name="arrow-right" />
<Icon name="heart" filled color="var(--accent)" size={16} />   // saved / liked
<Icon name="star" filled size={14} />                          // rating
<Icon name="shopping-bag" size={20} />                         // any Lucide name
<Button iconRight={<Icon name="arrow-right" size={16} />}>Submit Entry</Button>
```

A small inline geometry fallback covers the core glyphs (arrows, chevrons, x, search, moon/sun, heart, star, play) so icons still paint before the CDN resolves and if it is ever unreachable (offline). Pin lives in `Icon.jsx` (`LUCIDE_VERSION`). Country flags and the brand "×" lockup are content/typography, not icons — they are not part of this set.
