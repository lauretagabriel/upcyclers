import type { CSSProperties } from 'react';

/** Common Lucide glyph names used across the system. Any valid Lucide name
 *  (kebab-case, e.g. 'shopping-bag') also works — see https://lucide.dev/icons. */
export type IconName =
  | 'arrow-right'
  | 'arrow-left'
  | 'arrow-up-right'
  | 'chevron-left'
  | 'chevron-right'
  | 'chevron-down'
  | 'x'
  | 'search'
  | 'moon'
  | 'sun'
  | 'heart'
  | 'star'
  | 'play'
  | (string & {});

/**
 * Lucide icon, loaded from the official pinned CDN (window.lucide UMD build).
 * All UI glyphs in the system come from here — never inline ad-hoc SVG or emoji
 * for an interface affordance. A small inline fallback covers core glyphs so
 * icons still render before the CDN resolves / offline.
 */
export interface IconProps {
  /** Lucide glyph name (kebab-case). Any valid Lucide icon name works. */
  name: IconName;
  /** Pixel size (width = height). @default 18 */
  size?: number;
  /** Stroke weight on the 24px grid. @default 2 */
  strokeWidth?: number;
  /** Fill the glyph with currentColor (saved heart, rating star). @default false */
  filled?: boolean;
  /** Explicit fill override; takes precedence over `filled`. */
  fill?: string;
  /** Stroke color. @default 'currentColor' */
  color?: string;
  className?: string;
  style?: CSSProperties;
}

export function Icon(props: IconProps): JSX.Element | null;
