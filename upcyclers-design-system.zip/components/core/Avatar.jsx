import React from 'react';

const SIZES = { sm: 34, md: 40, lg: 46, xl: 56 };

/**
 * Avatar — circular creator/seller mark. Renders an image when `src` is given,
 * otherwise initials on a chip fill.
 */
export function Avatar({ name, src, initials, size = 'md', ring = false, alt, className, style, ...rest }) {
  const px = typeof size === 'number' ? size : (SIZES[size] || 40);
  const auto = (name || '')
    .trim()
    .split(/\s+/)
    .map((w) => w[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();
  const label = initials || auto || '?';

  const box = {
    width: px,
    height: px,
    flex: '0 0 auto',
    borderRadius: '50%',
    overflow: 'hidden',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    background: 'var(--chip)',
    color: 'var(--fg)',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-extrabold)',
    fontSize: Math.round(px * 0.36),
    lineHeight: 1,
    border: ring ? '1px solid var(--border-strong)' : 'none',
    ...style,
  };

  return (
    <div className={['uc-avatar', className].filter(Boolean).join(' ')} style={box} title={name} {...rest}>
      {src ? (
        <img src={src} alt={alt || name || ''} style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
      ) : (
        label
      )}
    </div>
  );
}
