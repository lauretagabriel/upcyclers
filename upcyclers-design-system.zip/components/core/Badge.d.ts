import type { ReactNode, CSSProperties } from 'react';

export interface BadgeProps {
  children?: ReactNode;
  /** @default 'neutral' */
  tone?: 'neutral' | 'accent' | 'solid' | 'invert';
  icon?: ReactNode;
  className?: string;
  style?: CSSProperties;
}

/** Tiny uppercase status label (Verified buyer, Seller, rank, New). */
export function Badge(props: BadgeProps): JSX.Element;
