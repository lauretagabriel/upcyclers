**Badge** — tiny uppercase status pill. Verified buyer, Seller, challenge rank, "New drop".

```jsx
<Badge icon={<span>✓</span>}>Verified buyer</Badge>
<Badge tone="solid">Live</Badge>
```

`tone`: neutral · accent (red wash) · solid (red) · invert (fg fill).
