import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';

export interface TagProps {
  children?: ReactNode;
  /** @default 'default' */
  variant?: 'default' | 'outline' | 'solid';
  /** @default 'md' */
  size?: 'sm' | 'md';
  /** Filled selected state (for filter chips). @default false */
  selected?: boolean;
  icon?: ReactNode;
  /** Makes the chip interactive (hover + role=button). */
  onClick?: MouseEventHandler;
  className?: string;
  style?: CSSProperties;
}

/** Pill chip for materials, categories and filters. */
export function Tag(props: TagProps): JSX.Element;
