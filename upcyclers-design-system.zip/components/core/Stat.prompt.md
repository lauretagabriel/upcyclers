**Stat** — a big Bebas Neue number over a label. Impact metrics, prize amounts, judging weights.

```jsx
<Stat value="$750" label="First Prize" align="center" />
<Stat value={<>2,000<span style={{fontSize:'.45em'}}>L</span></>} label="Water saved" sublabel="Est. vs. new denim" />
<Stat value="40%" label="Creativity" sublabel="Points" accent />
```

`accent` colors the number red — use for just one per group.
