import React from 'react';

const NUM = { sm: '40px', md: '56px', lg: 'var(--fs-stat)' };

/**
 * Stat — big Bebas Neue number over a label. Used for impact metrics, prizes
 * and judging weights. Set `accent` to color the number red (one per group).
 */
export function Stat({ value, label, sublabel, size = 'md', accent = false, align = 'left', className, style, ...rest }) {
  const wrap = { textAlign: align, ...style };
  return (
    <div className={['uc-stat', className].filter(Boolean).join(' ')} style={wrap} {...rest}>
      <div style={{
        fontFamily: 'var(--font-display)',
        fontWeight: 'var(--fw-display)',
        fontSize: NUM[size] || NUM.md,
        lineHeight: 'var(--lh-tight)',
        letterSpacing: 'var(--ls-display)',
        color: accent ? 'var(--accent)' : 'var(--fg)',
      }}>{value}</div>
      {label ? (
        <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-bold)', fontSize: '14px', marginTop: '8px', color: 'var(--fg)' }}>{label}</div>
      ) : null}
      {sublabel ? (
        <div style={{ fontFamily: 'var(--font-sans)', fontSize: '12.5px', marginTop: '4px', color: 'var(--muted-2)' }}>{sublabel}</div>
      ) : null}
    </div>
  );
}
