import type { ReactNode, CSSProperties } from 'react';

export interface StatProps {
  /** The big number — string or node (e.g. 2,000 with a small "L"). */
  value: ReactNode;
  label?: ReactNode;
  sublabel?: ReactNode;
  /** @default 'md' */
  size?: 'sm' | 'md' | 'lg';
  /** Color the number red — use for one highlight per group. @default false */
  accent?: boolean;
  /** @default 'left' */
  align?: 'left' | 'center' | 'right';
  className?: string;
  style?: CSSProperties;
}

/** Big Bebas number + label for impact metrics, prizes and judging weights. */
export function Stat(props: StatProps): JSX.Element;
