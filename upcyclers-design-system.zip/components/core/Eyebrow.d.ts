import type { ReactNode, CSSProperties } from 'react';

export interface EyebrowProps {
  children?: ReactNode;
  /** Color role. @default 'accent' */
  tone?: 'accent' | 'muted' | 'fg';
  /** Element tag. @default 'div' */
  as?: keyof JSX.IntrinsicElements;
  className?: string;
  style?: CSSProperties;
}

/** Uppercase kicker label above section titles. */
export function Eyebrow(props: EyebrowProps): JSX.Element;
