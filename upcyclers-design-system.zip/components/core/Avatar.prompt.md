**Avatar** — circular creator/seller mark, image or initials.

```jsx
<Avatar name="Priya N." />
<Avatar src={photo} name="22 Shades of Gray" initials="22" size="lg" ring />
```

`size`: sm 34 · md 40 · lg 46 · xl 56, or a number. Falls back to initials from `name` (or the `initials` override).
