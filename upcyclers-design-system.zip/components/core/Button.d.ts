import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';

/**
 * The Upcyclers pill button.
 * @startingPoint section="Core" subtitle="Primary / secondary / ghost pill buttons" viewport="700x150"
 */
export interface ButtonProps {
  children?: ReactNode;
  /** Visual weight. @default 'primary' */
  variant?: 'primary' | 'secondary' | 'ghost';
  /** @default 'md' */
  size?: 'sm' | 'md' | 'lg';
  /** Render as an anchor when set. */
  href?: string;
  onClick?: MouseEventHandler;
  /** Node placed before the label (e.g. an icon). */
  iconLeft?: ReactNode;
  /** Node placed after the label (commonly a → arrow). */
  iconRight?: ReactNode;
  /** Stretch to fill the container width. @default false */
  block?: boolean;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  className?: string;
  style?: CSSProperties;
}

export function Button(props: ButtonProps): JSX.Element;
