import type { CSSProperties } from 'react';

export interface AvatarProps {
  /** Full name — used for initials and the title tooltip. */
  name?: string;
  /** Image URL; when present, shown instead of initials. */
  src?: string;
  /** Explicit initials override (e.g. brand handles like "22"). */
  initials?: string;
  /** Named step or explicit pixel diameter. @default 'md' */
  size?: 'sm' | 'md' | 'lg' | 'xl' | number;
  /** Hairline ring around the circle. @default false */
  ring?: boolean;
  alt?: string;
  className?: string;
  style?: CSSProperties;
}

/** Circular creator/seller avatar (image or initials). */
export function Avatar(props: AvatarProps): JSX.Element;
