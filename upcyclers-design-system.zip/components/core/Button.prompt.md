**Button** — the brand's rounded pill button; use for every call-to-action and inline action. Primary = white(ink) fill for the main action, secondary = hairline outline, ghost = bare text for "→" links.

```jsx
<Button href="#" iconRight={<span>→</span>}>Submit Entry</Button>
<Button variant="secondary">Follow</Button>
<Button variant="ghost" iconRight={<span>→</span>}>View all entries</Button>
```

Sizes `sm | md | lg`. Renders `<a>` when `href` is set, otherwise `<button>`. Supports `block`, `disabled`, `iconLeft`/`iconRight`.
