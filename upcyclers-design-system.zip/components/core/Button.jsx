import React from 'react';

const SIZES = {
  sm: { padding: '9px 18px', fontSize: '13px' },
  md: { padding: '13px 26px', fontSize: '14px' },
  lg: { padding: '16px 34px', fontSize: '16px' },
};

/**
 * Button — the brand's pill button. White(→ink) fill for primary actions,
 * hairline outline for secondary, bare text for inline "→" links.
 */
export function Button({
  children,
  variant = 'primary',
  size = 'md',
  href,
  onClick,
  iconLeft,
  iconRight,
  block = false,
  disabled = false,
  type = 'button',
  className,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const on = hover && !disabled;

  const base = {
    display: block ? 'flex' : 'inline-flex',
    width: block ? '100%' : undefined,
    alignItems: 'center',
    justifyContent: 'center',
    gap: '10px',
    fontFamily: 'var(--font-sans)',
    fontSize: s.fontSize,
    fontWeight: 700,
    lineHeight: 1,
    letterSpacing: '.01em',
    padding: s.padding,
    borderRadius: 'var(--radius-pill)',
    border: '1px solid transparent',
    cursor: disabled ? 'not-allowed' : 'pointer',
    textDecoration: 'none',
    whiteSpace: 'nowrap',
    boxSizing: 'border-box',
    transition: 'opacity var(--t-fast), background var(--t-fast), border-color var(--t-fast), color var(--t-fast), transform var(--t-fast)',
    transform: active && !disabled ? 'scale(var(--press-scale))' : 'none',
    opacity: disabled ? 0.4 : 1,
  };

  const variants = {
    primary: {
      background: 'var(--btn-bg)',
      color: 'var(--btn-fg)',
      ...(on ? { opacity: 0.86 } : null),
    },
    secondary: {
      background: on ? 'var(--chip)' : 'transparent',
      color: 'var(--fg)',
      borderColor: on ? 'var(--fg)' : 'var(--border-strong)',
    },
    ghost: {
      background: 'transparent',
      color: on ? 'var(--accent-2)' : 'var(--fg)',
      padding: '2px 0',
      borderRadius: 0,
    },
  };

  const cls = ['uc-button', className].filter(Boolean).join(' ');
  const merged = { ...base, ...(variants[variant] || variants.primary), ...style };
  const bind = {
    className: cls,
    style: merged,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => { setHover(false); setActive(false); },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    ...rest,
  };

  const inner = (
    <>
      {iconLeft ? <span style={{ display: 'inline-flex', flex: '0 0 auto' }}>{iconLeft}</span> : null}
      {children != null ? <span>{children}</span> : null}
      {iconRight ? <span style={{ display: 'inline-flex', flex: '0 0 auto' }}>{iconRight}</span> : null}
    </>
  );

  if (href && !disabled) {
    return <a href={href} onClick={onClick} {...bind}>{inner}</a>;
  }
  return (
    <button type={type} onClick={onClick} disabled={disabled} aria-disabled={disabled || undefined} {...bind}>
      {inner}
    </button>
  );
}
