**Eyebrow** — the brand's uppercase kicker that sits above titles ("THE STORY", "CHALLENGE DETAILS").

```jsx
<Eyebrow>Challenge Details</Eyebrow>
<Eyebrow tone="muted">Community Voting Ends</Eyebrow>
```

`tone`: accent (red on dark) · muted · fg.
