import React from 'react';

/**
 * Badge — tiny uppercase label. Verified buyer, Seller, challenge rank, "New".
 */
export function Badge({ children, tone = 'neutral', icon, className, style, ...rest }) {
  const tones = {
    neutral: { background: 'var(--chip)', color: 'var(--muted)' },
    accent: { background: 'var(--accent-soft)', color: 'var(--accent-2)' },
    solid: { background: 'var(--accent-2)', color: '#fff' },
    invert: { background: 'var(--fg)', color: 'var(--bg)' },
  };
  const merged = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '4px',
    fontFamily: 'var(--font-sans)',
    fontSize: '10px',
    fontWeight: 'var(--fw-extrabold)',
    letterSpacing: '.06em',
    textTransform: 'uppercase',
    padding: '3px 8px',
    borderRadius: 'var(--radius-pill)',
    lineHeight: 1.2,
    whiteSpace: 'nowrap',
    ...(tones[tone] || tones.neutral),
    ...style,
  };
  return (
    <span className={['uc-badge', className].filter(Boolean).join(' ')} style={merged} {...rest}>
      {icon ? <span style={{ display: 'inline-flex' }}>{icon}</span> : null}
      {children}
    </span>
  );
}
