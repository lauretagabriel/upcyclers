import React from 'react';

const SIZES = {
  sm: { padding: '5px 12px', fontSize: '12px' },
  md: { padding: '9px 16px', fontSize: '14px' },
};

/**
 * Tag — pill chip for materials, categories, filters and selectable options.
 */
export function Tag({
  children,
  variant = 'default',
  size = 'md',
  selected = false,
  icon,
  onClick,
  className,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const s = SIZES[size] || SIZES.md;
  const interactive = typeof onClick === 'function';

  const looks = {
    default: {
      background: 'var(--chip)',
      color: 'var(--fg)',
      border: '1px solid var(--border-strong)',
    },
    outline: {
      background: 'transparent',
      color: 'var(--muted)',
      border: '1px solid var(--border-strong)',
    },
    solid: {
      background: 'var(--accent-soft)',
      color: 'var(--accent-2)',
      border: '1px solid transparent',
    },
  };
  const sel = selected
    ? { background: 'var(--fg)', color: 'var(--bg)', border: '1px solid var(--fg)' }
    : null;

  const merged = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: '7px',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-semibold)',
    fontSize: s.fontSize,
    lineHeight: 1,
    padding: s.padding,
    borderRadius: 'var(--radius-pill)',
    cursor: interactive ? 'pointer' : 'default',
    transition: 'background var(--t-fast), border-color var(--t-fast), color var(--t-fast)',
    ...(looks[variant] || looks.default),
    ...(interactive && hover && !selected ? { borderColor: 'var(--fg)' } : null),
    ...sel,
    ...style,
  };

  return (
    <span
      className={['uc-tag', className].filter(Boolean).join(' ')}
      style={merged}
      onClick={onClick}
      onMouseEnter={interactive ? () => setHover(true) : undefined}
      onMouseLeave={interactive ? () => setHover(false) : undefined}
      role={interactive ? 'button' : undefined}
      tabIndex={interactive ? 0 : undefined}
      {...rest}
    >
      {icon ? <span style={{ display: 'inline-flex' }}>{icon}</span> : null}
      {children}
    </span>
  );
}
