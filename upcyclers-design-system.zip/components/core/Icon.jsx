import React from 'react';

/**
 * Icon — official Lucide (https://lucide.dev, ISC), loaded from the pinned CDN
 * UMD build. Any Lucide icon name works (kebab-case, e.g. "arrow-right",
 * "shopping-bag"). The component reads the icon's node data off window.lucide
 * and renders it into an <svg> we control (size / stroke / fill / color).
 *
 * A small inline geometry fallback covers the core UI glyphs so icons still
 * paint before the CDN resolves and if it is ever unreachable (offline).
 */
const LUCIDE_VERSION = '0.552.0';
const LUCIDE_SRC = `https://unpkg.com/lucide@${LUCIDE_VERSION}/dist/umd/lucide.min.js`;

// Offline / pre-load fallback — inner markup on the Lucide 24px grid.
const FALLBACK = {
  'arrow-right': '<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>',
  'arrow-left': '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
  'arrow-up-right': '<path d="M7 7h10v10"/><path d="M7 17 17 7"/>',
  'chevron-left': '<path d="m15 18-6-6 6-6"/>',
  'chevron-right': '<path d="m9 18 6-6-6-6"/>',
  'chevron-down': '<path d="m6 9 6 6 6-6"/>',
  x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
  heart: '<path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/>',
  star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
  play: '<polygon points="6 3 20 12 6 21 6 3"/>',
};

const toPascal = (name) =>
  String(name).split(/[-_]/).map((s) => s.charAt(0).toUpperCase() + s.slice(1)).join('');

// Singleton loader for the Lucide UMD global. Resolves null on failure so the
// caller falls back to inline geometry instead of throwing.
let lucidePromise = null;
function loadLucide() {
  if (typeof window === 'undefined') return Promise.resolve(null);
  if (window.lucide) return Promise.resolve(window.lucide);
  if (lucidePromise) return lucidePromise;
  lucidePromise = new Promise((resolve) => {
    const done = () => resolve(window.lucide || null);
    const existing = document.querySelector('script[data-lucide-cdn]');
    if (existing) {
      existing.addEventListener('load', done);
      existing.addEventListener('error', () => resolve(null));
      if (window.lucide) done();
      return;
    }
    const s = document.createElement('script');
    s.src = LUCIDE_SRC;
    s.async = true;
    s.crossOrigin = 'anonymous';
    s.setAttribute('data-lucide-cdn', LUCIDE_VERSION);
    s.onload = done;
    s.onerror = () => resolve(null);
    document.head.appendChild(s);
  });
  return lucidePromise;
}

// Lucide node -> React element. Nodes are [tag, attrs, children?].
function renderNode(node, key) {
  if (!Array.isArray(node)) return null;
  const [tag, attrs = {}, children] = node;
  return React.createElement(
    tag,
    { key, ...attrs },
    Array.isArray(children) ? children.map((c, i) => renderNode(c, i)) : undefined,
  );
}

function getIconNode(name) {
  const lucide = typeof window !== 'undefined' ? window.lucide : null;
  if (!lucide) return null;
  const p = toPascal(name);
  const node = (lucide.icons && lucide.icons[p]) || lucide[p];
  return Array.isArray(node) ? node : null;
}

export function Icon({
  name,
  size = 18,
  strokeWidth = 2,
  filled = false,
  fill,
  color = 'currentColor',
  className,
  style,
  ...rest
}) {
  // Re-render once the CDN global becomes available.
  const [, bump] = React.useReducer((x) => x + 1, 0);
  React.useEffect(() => {
    if (typeof window !== 'undefined' && !window.lucide) {
      let alive = true;
      loadLucide().then(() => { if (alive) bump(); });
      return () => { alive = false; };
    }
  }, []);

  const svgProps = {
    xmlns: 'http://www.w3.org/2000/svg',
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: fill != null ? fill : filled ? 'currentColor' : 'none',
    stroke: color,
    strokeWidth,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    className: ['uc-icon', className].filter(Boolean).join(' '),
    style: { display: 'inline-block', flex: '0 0 auto', verticalAlign: 'middle', ...style },
    'aria-hidden': true,
    focusable: false,
    ...rest,
  };

  const node = getIconNode(name);
  if (node) {
    return React.createElement('svg', svgProps, node.map((c, i) => renderNode(c, i)));
  }

  const inner = FALLBACK[name];
  if (!inner) return null; // unknown name, CDN not ready yet — paints on next render
  return React.createElement('svg', { ...svgProps, dangerouslySetInnerHTML: { __html: inner } });
}
