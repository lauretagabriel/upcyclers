import React from 'react';

/**
 * Eyebrow — small uppercase kicker above titles. Red on dark (accent),
 * ink on light. The brand's signature section label.
 */
export function Eyebrow({ children, tone = 'accent', as = 'div', className, style, ...rest }) {
  const Tag = as;
  const color = tone === 'accent' ? 'var(--accent)' : tone === 'muted' ? 'var(--muted-2)' : 'var(--fg)';
  const merged = {
    fontFamily: 'var(--font-sans)',
    fontSize: 'var(--fs-eyebrow)',
    fontWeight: 'var(--fw-bold)',
    letterSpacing: 'var(--ls-eyebrow)',
    textTransform: 'uppercase',
    lineHeight: 1.2,
    color,
    ...style,
  };
  return (
    <Tag className={['uc-eyebrow', className].filter(Boolean).join(' ')} style={merged} {...rest}>
      {children}
    </Tag>
  );
}
