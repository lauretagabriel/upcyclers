import React from 'react';
import { Countdown } from './Countdown.jsx';

/**
 * ChallengeHero — the featured quarterly-challenge hero for the homepage and
 * the reusable template for each new challenge. Decluttered editorial layout:
 * the cutout image fills the section as a bottom-right background (never cropped
 * on the sides), a theme-aware scrim keeps the left detail column readable, and
 * the content groups into calm zones — lockup, edition eyebrow, mega hashtag
 * title, lead, a compact facts strip, one dominant countdown, and actions.
 */
const CH_CSS = `
.uc-challenge-hero{position:relative;overflow:hidden;min-height:clamp(540px,56vw,760px)}
.uc-challenge-hero .uc-ch-bg{position:absolute;inset:0;z-index:0;width:100%;max-width:var(--container);margin:0 auto;padding:0 var(--gutter);box-sizing:border-box;background-repeat:no-repeat;background-position:bottom right;background-origin:content-box;background-size:contain;background-image:var(--ch-bg)}
.uc-challenge-hero .uc-ch-scrim{position:absolute;inset:0;z-index:1}
.uc-challenge-hero[data-variant="editorial"] .uc-ch-scrim{background:linear-gradient(100deg, var(--bg) 0%, var(--bg) 33%, color-mix(in srgb, var(--bg) 60%, transparent) 51%, transparent 74%)}
.uc-challenge-hero[data-variant="panel"] .uc-ch-scrim{background:linear-gradient(100deg, color-mix(in srgb, var(--bg) 72%, transparent) 0%, color-mix(in srgb, var(--bg) 28%, transparent) 46%, transparent 72%)}
.uc-challenge-hero[data-variant="spotlight"] .uc-ch-scrim{background:linear-gradient(88deg, var(--bg) 0%, color-mix(in srgb, var(--bg) 52%, transparent) 42%, transparent 72%)}
.uc-challenge-hero .uc-ch-inner{position:relative;z-index:2;max-width:var(--container);margin:0 auto;padding:clamp(30px,5vw,64px) var(--gutter);min-height:inherit;display:flex;align-items:center}
.uc-challenge-hero[data-variant="spotlight"] .uc-ch-inner{align-items:flex-start}
.uc-challenge-hero .uc-ch-text{display:flex;flex-direction:column;max-width:min(680px,100%);min-width:0}
.uc-challenge-hero[data-variant="panel"] .uc-ch-text{background:color-mix(in srgb, var(--surface-2) 84%, transparent);backdrop-filter:var(--blur);-webkit-backdrop-filter:var(--blur);border:1px solid var(--border);border-radius:var(--radius-lg);padding:clamp(26px,3vw,42px)}
.uc-challenge-hero .uc-ch-lockup{display:flex;align-items:center;gap:16px;margin-bottom:clamp(24px,4vw,38px)}
.uc-challenge-hero .uc-ch-lockup img.wm{height:26px;width:auto;display:block;filter:var(--logo-filter,none)}
.uc-challenge-hero .uc-ch-lockup .x{color:var(--muted-2);font-size:19px;line-height:1;font-weight:var(--fw-regular)}
.uc-challenge-hero .uc-ch-lockup img.partner{height:46px;width:auto;display:block}
.uc-challenge-hero .uc-ch-eyebrow{font-family:var(--font-sans);font-weight:var(--fw-bold);font-size:var(--fs-eyebrow);line-height:1;letter-spacing:var(--ls-eyebrow);text-transform:uppercase;color:#EE3124;margin-bottom:16px}
.uc-challenge-hero .uc-ch-title{font-family:var(--font-display);font-weight:400;font-size:clamp(46px,6.6vw,80px);letter-spacing:normal;line-height:1;margin:0;color:var(--fg);overflow-wrap:break-word;text-transform:uppercase}
.uc-challenge-hero .uc-ch-title .hl{color:var(--accent)}
.uc-challenge-hero .uc-ch-lead{font-family:var(--font-sans);font-weight:var(--fw-medium);font-size:var(--fs-lead);line-height:1.5;color:var(--muted);margin:18px 0 0;max-width:440px;text-wrap:pretty}
.uc-challenge-hero .uc-ch-facts{display:flex;flex-wrap:nowrap;gap:clamp(16px,2.2vw,28px);margin-top:clamp(26px,3.6vw,38px)}
.uc-challenge-hero .uc-ch-fact{display:flex;flex-direction:column;gap:7px;min-width:0}
.uc-challenge-hero .uc-ch-fact+.uc-ch-fact{border-left:1px solid var(--border-strong);padding-left:clamp(16px,2.2vw,28px)}
.uc-challenge-hero .uc-ch-fact .fl{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:10px;line-height:1;letter-spacing:.15em;text-transform:uppercase;color:var(--faint)}
.uc-challenge-hero .uc-ch-fact .fv{font-family:var(--font-display);font-weight:400;font-size:24px;line-height:1.05;letter-spacing:.02em;color:var(--fg);white-space:nowrap}
.uc-challenge-hero .uc-ch-fact .fv.prize{font-size:28px;letter-spacing:-.01em;color:var(--fg);align-self:flex-start;border-bottom:3px solid var(--uc-red);padding-bottom:4px}
.uc-challenge-hero .uc-ch-fact .fsub{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:11px;line-height:1;letter-spacing:.05em;color:var(--fg);margin-top:2px}
.uc-challenge-hero .uc-ch-timer{margin-top:clamp(14px,2vw,22px)}
.uc-challenge-hero .uc-ch-timer .tl{display:flex;flex-wrap:wrap;align-items:baseline;gap:10px;margin-bottom:13px}
.uc-challenge-hero .uc-ch-timer .tl .lab{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:12px;line-height:1;letter-spacing:.06em;text-transform:uppercase;color:var(--faint)}
.uc-challenge-hero .uc-ch-timer .tl .note{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:11px;line-height:1;letter-spacing:.14em;text-transform:uppercase;color:var(--muted-2)}
.uc-challenge-hero .uc-ch-actions{display:flex;flex-wrap:wrap;gap:12px;margin-top:clamp(26px,3.6vw,34px)}
.uc-challenge-hero .uc-ch-credits{position:absolute;right:clamp(16px,4vw,40px);bottom:clamp(14px,3vw,26px);display:flex;flex-wrap:nowrap;justify-content:flex-end;align-items:baseline;gap:clamp(8px,1.4vw,16px);line-height:1.4;z-index:3}
.uc-challenge-hero .uc-ch-credits .cr{font-family:var(--font-sans);font-weight:var(--fw-semibold);font-size:11px;letter-spacing:.04em;color:rgba(255,255,255,.85);white-space:nowrap;text-shadow:0 1px 4px rgba(0,0,0,.75),0 0 2px rgba(0,0,0,.55)}
.uc-challenge-hero .uc-ch-credits .cr b{color:#fff;font-weight:var(--fw-bold)}
@media(max-width:880px){
  .uc-challenge-hero{min-height:clamp(660px,138vw,940px)}
  .uc-challenge-hero .uc-ch-bg{padding:0;background-image:var(--ch-bg-mobile);background-size:cover;background-position:top center}
  .uc-challenge-hero[data-variant] .uc-ch-scrim{background:linear-gradient(to bottom, rgba(0,0,0,0) 0%, rgba(0,0,0,.12) 30%, rgba(0,0,0,.6) 62%, rgba(0,0,0,.97) 100%)}
  .uc-challenge-hero[data-variant] .uc-ch-inner{align-items:flex-end;justify-content:center;padding-bottom:clamp(26px,7vw,54px)}
  .uc-challenge-hero .uc-ch-text{max-width:100%;align-items:center;text-align:center;--fg:#fff;--muted:rgba(255,255,255,.82);--muted-2:rgba(255,255,255,.6);--faint:rgba(255,255,255,.58);--border-strong:rgba(255,255,255,.24)}
  .uc-challenge-hero .uc-ch-lockup{justify-content:center;margin-bottom:clamp(14px,3vw,22px)}
  .uc-challenge-hero .uc-ch-lead{margin-left:auto;margin-right:auto}
  .uc-challenge-hero[data-variant="panel"] .uc-ch-text{padding:clamp(20px,5vw,28px)}
  .uc-challenge-hero .uc-ch-facts{flex-wrap:wrap;gap:12px 16px;justify-content:center}
  .uc-challenge-hero .uc-ch-fact{align-items:center}
  .uc-challenge-hero .uc-ch-fact .fv{font-size:20px}
  .uc-challenge-hero .uc-ch-fact+.uc-ch-fact{padding-left:14px}
  .uc-challenge-hero .uc-ch-timer{display:flex;flex-direction:column;align-items:center;margin-top:12px;margin-bottom:-4px}
  .uc-challenge-hero .uc-ch-timer .tl{justify-content:center}
  .uc-challenge-hero .uc-ch-timer .uc-countdown{transform:scale(.8);transform-origin:top center}
  .uc-challenge-hero .uc-ch-actions{justify-content:center}
  .uc-challenge-hero .uc-ch-credits{left:8px;right:8px;justify-content:center;flex-wrap:nowrap;gap:8px}
  .uc-challenge-hero .uc-ch-credits .cr{font-size:clamp(8px,2.4vw,10px);letter-spacing:.02em}
}
`;

export function ChallengeHero({
  logoSrc,
  logoAlt = 'Upcyclers',
  partnerSrc,
  partnerAlt = '',
  edition,
  title,
  titleAs = 'h1',
  lead,
  facts = [],
  deadline,
  deadlineLabel = 'Submit & vote until Sep 26, 2026 @ 6pm PT',
  deadlineNote,
  showCountdown = true,
  variant = 'spotlight',
  actions,
  media,
  mediaMobile,
  mediaAlt = '',
  credits = [],
  showCredits = true,
  className,
  style,
  ...rest
}) {
  const TitleTag = titleAs;
  const hasLockup = logoSrc || partnerSrc;
  const hasCredits = showCredits && credits.length > 0;

  return (
    <section
      className={['uc-challenge-hero', className].filter(Boolean).join(' ')}
      data-variant={variant}
      style={{ position: 'relative', overflow: 'hidden', background: 'var(--bg)', borderBottom: '1px solid var(--border)', ...style }}
      {...rest}
    >
      <style dangerouslySetInnerHTML={{ __html: CH_CSS }} />
      {media ? <div className="uc-ch-bg" style={{ '--ch-bg': `url(${media})`, '--ch-bg-mobile': `url(${mediaMobile || media})` }} role="img" aria-label={mediaAlt} /> : null}
      <div className="uc-ch-scrim" aria-hidden="true" />

      <div className="uc-ch-inner">
        <div className="uc-ch-text">
          {hasLockup ? (
            <div className="uc-ch-lockup">
              {logoSrc ? <img className="wm" src={logoSrc} alt={logoAlt} /> : null}
              {logoSrc && partnerSrc ? <span className="x" aria-hidden="true">&times;</span> : null}
              {partnerSrc ? <img className="partner" src={partnerSrc} alt={partnerAlt} /> : null}
            </div>
          ) : null}
          {edition ? <div className="uc-ch-eyebrow">{edition}</div> : null}
          {title ? <TitleTag className="uc-ch-title">{title}</TitleTag> : null}
          {lead ? <p className="uc-ch-lead">{lead}</p> : null}
          {facts.length > 0 ? (
            <div className="uc-ch-facts">
              {facts.map((f, i) => (
                <div className="uc-ch-fact" key={i}>
                  <span className="fl">{f.label}</span>
                  <span className={f.prize ? 'fv prize' : 'fv'}>{f.value}</span>
                  {f.sub ? <span className="fsub">{f.sub}</span> : null}
                </div>
              ))}
            </div>
          ) : null}
          {showCountdown && deadline ? (
            <div className="uc-ch-timer">
              <div className="tl">
                <span className="lab">{deadlineLabel}</span>
                {deadlineNote ? <span className="note">{deadlineNote}</span> : null}
              </div>
              <Countdown target={deadline} size="sm" align="left" accentSeconds={false} style={{ gap: 'clamp(4px,1vw,12px)' }} />
            </div>
          ) : null}
          {actions ? <div className="uc-ch-actions">{actions}</div> : null}
        </div>
      </div>

      {hasCredits ? (
        <div className="uc-ch-credits">
          {credits.map((c, i) => (
            <div className="cr" key={i}>{c.role} <b>{c.name}</b></div>
          ))}
        </div>
      ) : null}
    </section>
  );
}
