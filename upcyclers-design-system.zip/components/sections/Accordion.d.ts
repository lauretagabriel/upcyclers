import type { ReactNode, CSSProperties } from 'react';

export interface AccordionItem {
  id: string;
  label: ReactNode;
  content: ReactNode;
}

export interface AccordionProps {
  items: AccordionItem[];
  /** single = one open at a time; multiple = independent. @default 'single' */
  type?: 'single' | 'multiple';
  /** Initially open id(s). */
  defaultOpen?: string | string[];
  /** +/- sign color. @default 'accent' */
  signTone?: 'accent' | 'muted';
  className?: string;
  style?: CSSProperties;
}

/** Expandable +/- sections (product details, challenge rules on mobile). */
export function Accordion(props: AccordionProps): JSX.Element;
