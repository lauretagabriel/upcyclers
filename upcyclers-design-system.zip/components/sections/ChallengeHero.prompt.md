**ChallengeHero** — the featured quarterly-challenge hero for the homepage, and the reusable template for every new challenge. An image-forward layout that keeps all the challenge detail but organizes it into calm zones so nothing competes: identity (brand lockup → edition eyebrow → mega hashtag title → lead), a compact facts strip, one dominant countdown, and actions — over the cutout hero image, which fills the section as a bottom-right background. Ships in the `spotlight` treatment by default (content anchored lower-left over a bottom scrim); `editorial` and `panel` are also available via `variant`.

```jsx
<ChallengeHero
  logoSrc="/assets/upcyclers-white.png"
  partnerSrc="/assets/salvation-army.png" partnerAlt="The Salvation Army Thrift Stores"
  edition="Global Upcycling Challenge 2026"
  title="#thriftflip"
  lead={<>Turn thrifted finds into <span style={{color:'var(--fg)',borderBottom:'3px solid var(--accent)'}}>one-of-a-kind</span>.</>}
  facts={[
    { label: 'Grand prize', value: '$750', prize: true },
    { label: 'Finals', value: 'Top 10', sub: 'Most Loved' },
    { label: 'Winner Announced', value: 'Sep 30, 2026' },
  ]}
  deadline="2026-09-26T18:00:00-07:00"
  actions={<Button iconRight={<Icon name="arrow-right" size={16} />}>View Challenge</Button>}
  media="/assets/challenge-hero-thriftflip.webp"
  mediaAlt="Reworked cream-and-denim hoodie by Cyced"
  credits={[
    { role: 'Upcycler', name: 'Cyced' },
    { role: 'Photography', name: 'Jason Asuncion' },
    { role: 'Model', name: 'Claudia Navas' },
  ]}
/>
```

**Decluttering built in** — the three legacy restatements of the deadline (entry-end, "community voting ends" sentence, and the timer) collapse into one countdown with a labelled note; the edition rides above the title as the eyebrow instead of a competing line below it; and the separate prize block, date grid, and voting sentence become one quiet facts strip. Only the countdown is a large number, so it reads as the single urgency anchor.

**Layout & theming** — the image is a section background positioned bottom-right and sized to `contain`, so it is **never cropped on the left or right**. A theme-aware scrim (`linear-gradient` built from `var(--bg)`) keeps the left detail column readable over the image in both light and dark mode. Credits sit on a dark corner gradient so they stay legible even where the image is white. Stacks to a single column under 880px (image drops to the bottom, scrim goes vertical).

**Props of note**
- `variant` — `spotlight` (default, image-forward), `editorial` (diagonal scrim + left column), or `panel` (detail column in a frosted card).
- `facts` — order by importance; set `prize: true` on the money one (renders white with a red underline rule) and add an optional `sub` for a small caption under any value (e.g. `value:'Top 10', sub:'Most Loved'`). Keep to ~3 so the strip stays scannable.
- `deadlineLabel` — the single merged deadline line above the countdown (default `'Submit & vote until Sep 26, 2026 @ 6pm PT'`, rendered faint).
- `showCountdown={false}` — for a challenge with no live timer (results phase, evergreen feature).
- `showCredits={false}` — hide the credit overlay (and its corner gradient).
- The brand wordmark in the lockup inherits `--logo-filter`, so it flips to ink automatically in light mode.
- Provide a **cutout** image (transparent background). It grounds at the bottom-right; a full-frame photo works too but reads less like the brand's editorial cutout style.

Uses `Countdown` internally (tightened digit spacing).
