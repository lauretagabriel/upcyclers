import React from 'react';

/**
 * Accordion — expandable +/- sections. Product details, challenge rules on
 * mobile. Bebas +/- signs; hairline dividers between rows.
 */
export function Accordion({
  items = [],
  type = 'single',
  defaultOpen,
  signTone = 'accent',
  className,
  style,
  ...rest
}) {
  const initial = () => {
    if (defaultOpen != null) return Array.isArray(defaultOpen) ? defaultOpen : [defaultOpen];
    if (type === 'single' && items[0]) return [items[0].id];
    return [];
  };
  const [open, setOpen] = React.useState(initial);

  const toggle = (id) => {
    setOpen((cur) => {
      const isOpen = cur.includes(id);
      if (type === 'multiple') return isOpen ? cur.filter((x) => x !== id) : [...cur, id];
      return isOpen ? [] : [id];
    });
  };

  const signColor = signTone === 'accent' ? 'var(--accent)' : 'var(--muted-2)';

  return (
    <div className={['uc-accordion', className].filter(Boolean).join(' ')} style={{ borderBottom: '1px solid var(--border)', ...style }} {...rest}>
      {items.map((it) => {
        const isOpen = open.includes(it.id);
        return (
          <div key={it.id} style={{ borderTop: '1px solid var(--border)' }}>
            <button
              onClick={() => toggle(it.id)}
              aria-expanded={isOpen}
              style={{
                display: 'flex', alignItems: 'center', justifyContent: 'space-between', width: '100%',
                appearance: 'none', border: 'none', background: 'transparent', cursor: 'pointer', textAlign: 'left',
                color: 'var(--fg)', fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-extrabold)',
                fontSize: 16, letterSpacing: '.02em', padding: '18px 2px',
              }}
            >
              <span>{it.label}</span>
              <span style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--fw-display)', fontSize: 26, color: signColor, lineHeight: 1 }}>{isOpen ? '\u2212' : '+'}</span>
            </button>
            {isOpen ? <div style={{ padding: '0 2px 22px', color: 'var(--muted)', fontSize: 14.5, lineHeight: 'var(--lh-body)' }}>{it.content}</div> : null}
          </div>
        );
      })}
    </div>
  );
}
