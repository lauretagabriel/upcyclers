import React from 'react';

/**
 * Hero — the brand's centered editorial hero (homepage, challenge, drops).
 * A kicker, a mega title (Montserrat 800 ultra-tight by default, or Bebas via
 * `display`), an optional Bebas subtitle, a lead line, action buttons, and
 * room for extra rows (prize / timeline) via children. Pass `media` for a
 * full-bleed background image with a scrim.
 */
export function Hero({
  eyebrow,
  brandLockup,
  title,
  titleAs = 'h1',
  display = false,
  subtitle,
  lead,
  actions,
  align = 'center',
  media,
  scrim = true,
  children,
  className,
  style,
  ...rest
}) {
  const TitleTag = titleAs;
  const centered = align === 'center';

  const titleStyle = display
    ? { fontFamily: 'var(--font-display)', fontWeight: 'var(--fw-display)', fontSize: 'var(--fs-hero)', letterSpacing: 'var(--ls-display)', lineHeight: 'var(--lh-tight)' }
    : { fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-extrabold)', fontSize: 'var(--fs-hero)', letterSpacing: 'var(--ls-hero)', lineHeight: 'var(--lh-mega)' };

  return (
    <header
      className={['uc-hero', className].filter(Boolean).join(' ')}
      style={{ position: 'relative', overflow: 'hidden', background: media ? 'var(--surface)' : 'transparent', ...style }}
      {...rest}
    >
      {media ? (
        <div style={{ position: 'absolute', inset: 0 }}>
          <img src={media} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
          {scrim ? <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(10,10,10,.35), rgba(10,10,10,.82))' }} /> : null}
        </div>
      ) : null}

      <div style={{
        position: 'relative', maxWidth: 'var(--container-text)', margin: '0 auto',
        padding: 'clamp(40px,7vw,72px) var(--gutter)', textAlign: centered ? 'center' : 'left',
        display: 'flex', flexDirection: 'column', alignItems: centered ? 'center' : 'flex-start', gap: 0,
      }}>
        {brandLockup ? <div style={{ marginBottom: 32 }}>{brandLockup}</div> : null}
        {eyebrow ? <div style={{ marginBottom: 16, fontFamily: 'var(--font-sans)', fontSize: 'var(--fs-eyebrow)', fontWeight: 'var(--fw-bold)', letterSpacing: 'var(--ls-eyebrow)', textTransform: 'uppercase', color: 'var(--accent)' }}>{eyebrow}</div> : null}
        <TitleTag style={{ margin: 0, color: 'var(--fg)', ...titleStyle }}>{title}</TitleTag>
        {subtitle ? <p style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--fw-display)', fontSize: 'clamp(22px,4vw,38px)', letterSpacing: 'var(--ls-wide)', margin: '18px 0 0', color: 'var(--fg)' }}>{subtitle}</p> : null}
        {lead ? <p style={{ fontFamily: 'var(--font-sans)', fontSize: 'var(--fs-lead)', fontWeight: 'var(--fw-medium)', color: 'var(--muted)', margin: '16px 0 0', maxWidth: 640, textWrap: 'pretty' }}>{lead}</p> : null}
        {actions ? <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12, justifyContent: centered ? 'center' : 'flex-start', margin: '32px 0 0' }}>{actions}</div> : null}
        {children ? <div style={{ width: '100%', marginTop: 40 }}>{children}</div> : null}
      </div>
    </header>
  );
}
