**Hero** — the brand's centered editorial hero. Kicker + mega title (Montserrat 800 ultra-tight by default, Bebas via `display`), optional subtitle, lead, action buttons, and room for extra rows.

```jsx
<Hero
  brandLockup={<Lockup/>}
  title="#thriftflip"
  subtitle="Global Upcycling Challenge 2026"
  lead={<>Turn thrifted finds into <u>one-of-a-kind</u>.</>}
  actions={<Button iconRight={<span>→</span>}>Submit Entry</Button>}
/>
```

Pass `media` for a full-bleed background image (with a scrim).
