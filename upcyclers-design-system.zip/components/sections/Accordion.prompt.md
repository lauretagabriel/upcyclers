**Accordion** — expandable +/- sections with Bebas signs and hairline dividers.

```jsx
<Accordion type="single" items={[
  {id:'details', label:'Details', content:<Specs/>},
  {id:'materials', label:'Materials', content:<Chips/>},
]} />
```

`type="multiple"` lets several open at once; `signTone` sets the +/- color.
