import type { ReactNode, CSSProperties } from 'react';

/**
 * Centered editorial hero for homepage / challenge / drops.
 * @startingPoint section="Sections" subtitle="Centered editorial hero with kicker + mega title" viewport="1200x620"
 */
export interface HeroProps {
  eyebrow?: ReactNode;
  /** Co-brand lockup row (e.g. Upcyclers × Salvation Army). */
  brandLockup?: ReactNode;
  title: ReactNode;
  titleAs?: keyof JSX.IntrinsicElements;
  /** Use Bebas mega instead of Montserrat 800 ultra-tight. @default false */
  display?: boolean;
  /** Bebas subtitle line. */
  subtitle?: ReactNode;
  lead?: ReactNode;
  /** Action buttons row. */
  actions?: ReactNode;
  /** @default 'center' */
  align?: 'center' | 'left';
  /** Full-bleed background image URL. */
  media?: string;
  /** Dark scrim over the media. @default true */
  scrim?: boolean;
  children?: ReactNode;
  className?: string;
  style?: CSSProperties;
}

export function Hero(props: HeroProps): JSX.Element;
