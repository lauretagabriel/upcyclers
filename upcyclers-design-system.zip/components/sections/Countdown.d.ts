import type { CSSProperties } from 'react';

export interface CountdownProps {
  /** Target date — Date, ms timestamp, or parseable string. */
  target: Date | number | string;
  /** [days, hours, minutes, seconds] labels. */
  labels?: [string, string, string, string];
  /** @default 'lg' */
  size?: 'sm' | 'md' | 'lg';
  /** Color the seconds red. @default true */
  accentSeconds?: boolean;
  /** @default 'center' */
  align?: 'center' | 'left';
  onComplete?: () => void;
  className?: string;
  style?: CSSProperties;
}

/** Live Bebas Neue D:H:M:S countdown to a target date. */
export function Countdown(props: CountdownProps): JSX.Element;
