import type { ReactNode, CSSProperties } from 'react';

/** A single fact in the hero's compact meta strip. */
export interface ChallengeFact {
  /** Small uppercase label, e.g. "Grand prize". */
  label: string;
  /** The value, e.g. "$750" or "Top 10". */
  value: ReactNode;
  /** Optional small caption rendered under the value, e.g. "Most Loved". */
  sub?: ReactNode;
  /** Emphasize as the prize (white with a red underline rule). */
  prize?: boolean;
}

/** A photo/production credit line shown subtly over the hero image. */
export interface ChallengeCredit {
  /** Role, e.g. "Photography". */
  role: string;
  /** Name, e.g. "Jason Asuncion". */
  name: string;
}

/**
 * ChallengeHero — the featured quarterly-challenge hero for the homepage.
 * Decluttered two-column layout that retains all challenge detail but groups it
 * into calm zones: identity (lockup + edition + title + lead), a compact facts
 * strip, one dominant countdown, and actions — with the cutout hero image
 * filling the right column. Reusable as the template for each new challenge.
 * @startingPoint
 */
export interface ChallengeHeroProps {
  /** Upcyclers wordmark image src (white on dark). */
  logoSrc?: string;
  logoAlt?: string;
  /** Partner logo src (e.g. Salvation Army), shown after an "×". */
  partnerSrc?: string;
  partnerAlt?: string;
  /** Edition line shown as the accent eyebrow, e.g. "Global Upcycling Challenge 2026". */
  edition?: ReactNode;
  /** Mega title — the challenge hashtag, e.g. "#thriftflip". */
  title?: ReactNode;
  /** Heading tag for the title. @default 'h1' */
  titleAs?: keyof JSX.IntrinsicElements;
  /** Supporting lead line under the title. */
  lead?: ReactNode;
  /** Compact meta strip: prize, entry window, finals, winner. */
  facts?: ChallengeFact[];
  /** Target date/time for the countdown (Date, epoch ms, or ISO string). */
  deadline?: string | number | Date;
  /** Merged deadline line rendered above the countdown as one container.
   *  @default 'Submit & vote until Sep 26, 2026 @ 6pm PT' */
  deadlineLabel?: string;
  /** Optional extra note appended beside the label (usually left unset now). */
  deadlineNote?: string;
  /** Show the live countdown. @default true */
  showCountdown?: boolean;
  /** Design treatment. The image always stays a bottom-right background.
   *  - `spotlight` image-forward, content anchored lower-left over a bottom scrim (default)
   *  - `editorial` diagonal scrim + left detail column
   *  - `panel` detail column in a frosted card, image more exposed
   *  @default 'spotlight' */
  variant?: 'editorial' | 'panel' | 'spotlight';
  /** Action buttons (pass Button components). */
  actions?: ReactNode;
  /** Cutout hero image src (transparent PNG/WebP recommended). Fills the section
   *  as a bottom-right background, sized to contain (never cropped on the sides). */
  media?: string;
  mediaAlt?: string;
  /** Production credits shown over the image, on a dark corner gradient for legibility. */
  credits?: ChallengeCredit[];
  /** Show the credits overlay. @default true */
  showCredits?: boolean;
  className?: string;
  style?: CSSProperties;
}

export function ChallengeHero(props: ChallengeHeroProps): JSX.Element;
