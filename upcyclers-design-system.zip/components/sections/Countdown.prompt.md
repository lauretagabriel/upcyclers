**Countdown** — the big Bebas Neue timer counting down to a date; seconds accented red.

```jsx
<Countdown target="2026-09-26T18:00:00-07:00" />
<Countdown target={endDate} size="md" align="left" />
```
