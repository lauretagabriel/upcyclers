import React from 'react';

function parseTarget(t) {
  if (t instanceof Date) return t.getTime();
  if (typeof t === 'number') return t;
  if (typeof t === 'string') { const d = new Date(t).getTime(); return Number.isNaN(d) ? Date.now() : d; }
  return Date.now();
}
function compute(target) {
  let diff = target - Date.now();
  if (diff < 0) diff = 0;
  const p = (n) => String(n).padStart(2, '0');
  return {
    d: String(Math.floor(diff / 86400000)),
    h: p(Math.floor(diff / 3600000) % 24),
    m: p(Math.floor(diff / 60000) % 60),
    s: p(Math.floor(diff / 1000) % 60),
    done: diff === 0,
  };
}

const SIZES = { sm: 'clamp(36px,9vw,56px)', md: 'clamp(48px,12vw,90px)', lg: 'var(--fs-timer)' };

/**
 * Countdown — the brand's big Bebas Neue timer counting down to a target date.
 * Colon-separated D:H:M:S with the seconds accented in red.
 */
export function Countdown({
  target,
  labels = ['DAYS', 'HOURS', 'MINUTES', 'SECONDS'],
  size = 'lg',
  accentSeconds = true,
  align = 'center',
  onComplete,
  className,
  style,
  ...rest
}) {
  const ms = React.useMemo(() => parseTarget(target), [target]);
  const [t, setT] = React.useState(() => compute(ms));

  React.useEffect(() => {
    setT(compute(ms));
    const id = setInterval(() => {
      const next = compute(ms);
      setT(next);
      if (next.done && onComplete) onComplete();
    }, 1000);
    return () => clearInterval(id);
  }, [ms]);

  const digit = SIZES[size] || SIZES.lg;
  const colon = { fontFamily: 'var(--font-display)', fontWeight: 'var(--fw-display)', fontSize: `calc(${digit} * .8)`, color: 'var(--faint)', lineHeight: 1.05 };
  const cell = (value, label, accent) => (
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontFamily: 'var(--font-display)', fontWeight: 'var(--fw-display)', fontSize: digit, lineHeight: 'var(--lh-tight)', color: accent ? 'var(--accent)' : 'var(--fg)' }}>{value}</div>
      <div style={{ fontFamily: 'var(--font-sans)', color: 'var(--muted-2)', fontSize: 12, fontWeight: 'var(--fw-semibold)', letterSpacing: '.12em' }}>{label}</div>
    </div>
  );

  return (
    <div
      className={['uc-countdown', className].filter(Boolean).join(' ')}
      style={{ display: 'flex', alignItems: 'flex-start', justifyContent: align === 'center' ? 'center' : 'flex-start', gap: 'clamp(10px,4vw,44px)', ...style }}
      {...rest}
    >
      {cell(t.d, labels[0])}
      <div style={colon}>:</div>
      {cell(t.h, labels[1])}
      <div style={colon}>:</div>
      {cell(t.m, labels[2])}
      <div style={colon}>:</div>
      {cell(t.s, labels[3], accentSeconds)}
    </div>
  );
}
