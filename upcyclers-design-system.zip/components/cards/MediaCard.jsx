import React from 'react';
import { Icon } from '../core/Icon.jsx';

const PlayGlyph = () => (
  <span style={{
    width: 52, height: 52, borderRadius: '50%', background: 'rgba(0,0,0,.55)',
    backdropFilter: 'var(--blur)', WebkitBackdropFilter: 'var(--blur)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', border: '1px solid rgba(255,255,255,.25)',
  }}>
    <Icon name="play" size={18} filled color="#fff" style={{ marginLeft: 3 }} />
  </span>
);

/**
 * MediaCard — the brand's image/video card. The media sits in an inset frame
 * with its own rounded corners (`frame`, on by default); pass `frame={false}`
 * for an edge-to-edge thumbnail. Hover lifts the card and gently zooms the
 * media. Built to open a Gallery on click.
 */
export function MediaCard({
  image,
  video,
  poster,
  alt = '',
  aspect = '3/4',
  fit = 'cover',
  frame = true,
  topLeft,
  topRight,
  children,
  bodyPadding,
  onClick,
  href,
  hoverable = true,
  className,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const isVideo = !!video;
  const thumb = poster || image;
  const interactive = hoverable || typeof onClick === 'function' || !!href;
  const Tag = href ? 'a' : 'div';

  const leave = () => setHover(false);
  const handleClick = (e) => { setHover(false); if (onClick) onClick(e); };
  const bodyPad = bodyPadding != null ? bodyPadding : (frame ? '12px 0 2px' : '14px 15px 16px');

  return (
    <Tag
      href={href}
      className={['uc-mediacard', className].filter(Boolean).join(' ')}
      style={{
        display: 'block', background: 'var(--card-bg)', border: '1px solid var(--border)',
        borderRadius: 'var(--radius-md)', overflow: 'hidden', textDecoration: 'none', color: 'inherit',
        padding: frame ? 'var(--space-2)' : 0,
        cursor: interactive ? 'pointer' : 'default',
        transition: 'border-color var(--t)',
        ...(interactive && hover ? { border: '1px solid var(--border-strong)' } : null),
        ...style,
      }}
      onClick={interactive ? handleClick : onClick}
      onPointerEnter={interactive ? () => setHover(true) : undefined}
      onPointerLeave={interactive ? leave : undefined}
      onPointerCancel={interactive ? leave : undefined}
      onBlur={interactive ? leave : undefined}
      {...rest}
    >
      <div style={{
        position: 'relative', aspectRatio: aspect, width: '100%', overflow: 'hidden',
        background: 'var(--chip)', borderRadius: frame ? 'var(--radius-sm)' : 0,
      }}>
        {thumb ? (
          <img src={thumb} alt={alt} style={{
            width: '100%', height: '100%', objectFit: fit, display: 'block',
            transition: 'transform var(--t-slow)', transform: interactive && hover ? 'scale(1.04)' : 'none',
          }} />
        ) : (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--faint)', fontSize: 13 }}>{alt || 'Media'}</div>
        )}
        {isVideo ? (
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', pointerEvents: 'none' }}><PlayGlyph /></div>
        ) : null}
        {topLeft ? <div style={{ position: 'absolute', top: 10, left: 10 }}>{topLeft}</div> : null}
        {topRight ? <div style={{ position: 'absolute', top: 10, right: 10 }}>{topRight}</div> : null}
      </div>
      {children != null ? <div style={{ padding: bodyPad }}>{children}</div> : null}
    </Tag>
  );
}
