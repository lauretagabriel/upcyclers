import React from 'react';
import { Icon } from '../core/Icon.jsx';
import { MediaCard } from './MediaCard.jsx';

/**
 * PersonCard — a creator or challenge judge: portrait media over name, role,
 * short bio and an optional link. Wider 4/3 media by default.
 */
export function PersonCard({
  image, video, poster, alt, aspect = '4/3',
  name, role, bio, link, href, onClick,
  className, style, ...rest
}) {
  return (
    <MediaCard
      image={image} video={video} poster={poster} alt={alt || name} aspect={aspect}
      href={href} onClick={onClick} hoverable={!!(href || onClick)}
      className={className} style={style} bodyPadding="20px 22px 24px"
      {...rest}
    >
      <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-extrabold)', fontSize: 18, letterSpacing: '.03em', textTransform: 'uppercase', color: 'var(--fg)' }}>{name}</div>
      {role ? <div style={{ color: 'var(--accent)', fontSize: 13, fontWeight: 'var(--fw-bold)', margin: '4px 0 12px' }}>{role}</div> : null}
      {bio ? <div style={{ color: 'var(--muted)', fontSize: 14, lineHeight: 1.55 }}>{bio}</div> : null}
      {link ? <a href={link.href || '#'} style={{ display: 'inline-block', marginTop: 14, fontSize: 13, fontWeight: 'var(--fw-bold)' }}>{link.label || 'See more'} <Icon name="arrow-right" size={14} /></a> : null}
    </MediaCard>
  );
}
