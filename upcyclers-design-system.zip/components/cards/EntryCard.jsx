import React from 'react';
import { MediaCard } from './MediaCard.jsx';
import { Icon } from '../core/Icon.jsx';

/**
 * EntryCard — a challenge entry tile: media with a rank badge, title, creator
 * handle (with country flag) and a heart vote count. Supports image or video.
 */
export function EntryCard({
  image, video, poster, alt, aspect = '3/4',
  rank, title, handle, flag, votes, href, onClick,
  className, style, ...rest
}) {
  const rankBadge = rank != null ? (
    <span style={{
      width: 30, height: 30, borderRadius: '50%', background: 'rgba(0,0,0,.55)',
      backdropFilter: 'var(--blur)', WebkitBackdropFilter: 'var(--blur)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-bold)', fontSize: 13, color: '#fff',
    }}>{rank}</span>
  ) : null;

  return (
    <MediaCard
      image={image} video={video} poster={poster} alt={alt || title} aspect={aspect}
      href={href} onClick={onClick} className={className} style={style} topLeft={rankBadge}
      {...rest}
    >
      <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-bold)', fontSize: 15, lineHeight: 1.3, color: 'var(--fg)', minHeight: 39 }}>{title}</div>
      {(handle || flag) ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 10, color: 'var(--muted)', fontSize: 13 }}>
          {flag ? <span style={{ fontSize: 15 }}>{flag}</span> : null}<span>{handle}</span>
        </div>
      ) : null}
      {votes != null ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 9, color: 'var(--muted)', fontSize: 13 }}>
          <Icon name="heart" size={14} filled color="var(--accent)" /><span>{votes} votes</span>
        </div>
      ) : null}
    </MediaCard>
  );
}
