import React from 'react';
import { MediaCard } from './MediaCard.jsx';
import { Avatar } from '../core/Avatar.jsx';
import { Icon } from '../core/Icon.jsx';

function SaveButton({ saved, defaultSaved, onSave }) {
  const controlled = saved !== undefined;
  const [internal, setInternal] = React.useState(!!defaultSaved);
  const isSaved = controlled ? saved : internal;
  const toggle = (e) => {
    e.preventDefault(); e.stopPropagation();
    if (!controlled) setInternal((v) => !v);
    if (onSave) onSave();
  };
  return (
    <button
      aria-label={isSaved ? 'Saved' : 'Save'}
      aria-pressed={isSaved}
      onClick={toggle}
      style={{
        width: 34, height: 34, borderRadius: '50%', border: '1px solid rgba(255,255,255,.25)',
        background: 'rgba(0,0,0,.5)', backdropFilter: 'var(--blur)', WebkitBackdropFilter: 'var(--blur)',
        display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', padding: 0,
        color: isSaved ? 'var(--accent-2)' : '#fff', fontSize: 15, lineHeight: 1, transition: 'color var(--t)',
      }}
    ><Icon name="heart" size={17} filled={isSaved} /></button>
  );
}

/**
 * ProductCard — a marketplace listing: media, title, seller, price and a save
 * (heart) control. Composes MediaCard so it supports image OR video.
 */
export function ProductCard({
  image, video, poster, alt, aspect = '3/4',
  title, seller, price, hearts, badge,
  saved, defaultSaved, onSave, href, onClick,
  className, style, ...rest
}) {
  return (
    <MediaCard
      image={image} video={video} poster={poster} alt={alt || title} aspect={aspect}
      href={href} onClick={onClick} className={className} style={style}
      topLeft={badge}
      topRight={<SaveButton saved={saved} defaultSaved={defaultSaved} onSave={onSave} />}
      {...rest}
    >
      <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-bold)', fontSize: 15, lineHeight: 1.3, color: 'var(--fg)' }}>{title}</div>
      {seller ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 10 }}>
          <Avatar name={seller.name} src={seller.avatar} initials={seller.initials} size={22} />
          <span style={{ color: 'var(--muted-2)', fontSize: 13, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{seller.handle || seller.name}</span>
        </div>
      ) : null}
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: 8, marginTop: 12 }}>
        {price != null ? <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-extrabold)', fontSize: 17, letterSpacing: '-.01em', color: 'var(--fg)' }}>{price}</span> : <span />}
        {hearts != null ? (
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, color: 'var(--muted-2)', fontSize: 13 }}>
            <Icon name="heart" size={13} filled color="var(--accent)" />{hearts}
          </span>
        ) : null}
      </div>
    </MediaCard>
  );
}
