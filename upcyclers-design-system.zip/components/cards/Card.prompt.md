**Card** — base surface panel with the brand's hairline border + radius. Use for any custom panel; the media/product/entry/person cards compose it.

```jsx
<Card>Impact summary…</Card>
<Card surface="surface" hoverable onClick={open}>…</Card>
```

`surface`: panel (inset) · surface (raised) · plain · any CSS color.
