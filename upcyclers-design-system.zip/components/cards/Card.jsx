import React from 'react';

/**
 * Card — base surface container. Hairline border, brand radius, solid/inset fill.
 * The building block other cards compose; use directly for arbitrary panels.
 */
export function Card({
  children,
  surface = 'panel',
  padded = true,
  hoverable = false,
  as = 'div',
  href,
  onClick,
  className,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const fills = {
    panel: 'var(--panel)',
    surface: 'var(--card-bg)',
    plain: 'transparent',
  };
  const bg = fills[surface] || surface;
  const interactive = hoverable || typeof onClick === 'function' || !!href;
  const leave = () => setHover(false);
  const handleClick = (e) => { setHover(false); if (onClick) onClick(e); };

  const merged = {
    background: bg,
    border: '1px solid var(--border)',
    borderRadius: 'var(--radius-md)',
    overflow: 'hidden',
    padding: padded ? 'var(--space-6)' : 0,
    display: 'block',
    textDecoration: 'none',
    color: 'inherit',
    transition: 'border-color var(--t)',
    ...(interactive ? { cursor: 'pointer' } : null),
    ...(interactive && hover
      ? { border: '1px solid var(--border-strong)' }
      : null),
    ...style,
  };

  const Tag = href ? 'a' : as;
  return (
    <Tag
      href={href}
      onClick={interactive ? handleClick : onClick}
      className={['uc-card', className].filter(Boolean).join(' ')}
      style={merged}
      onPointerEnter={interactive ? () => setHover(true) : undefined}
      onPointerLeave={interactive ? leave : undefined}
      onPointerCancel={interactive ? leave : undefined}
      onBlur={interactive ? leave : undefined}
      {...rest}
    >
      {children}
    </Tag>
  );
}
