**EntryCard** — a challenge entry in the Top 10 / all-entries grid: media with a rank badge, title, creator handle with country flag, and a heart vote count.

```jsx
<EntryCard rank={1} image={url} title="Storm-dyed trench, reborn"
  flag="🇺🇸" handle="@denimghost" votes="1,204" href="#" />
```
