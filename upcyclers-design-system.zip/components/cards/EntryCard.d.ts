import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';

export interface EntryCardProps {
  image?: string;
  video?: string;
  poster?: string;
  alt?: string;
  /** @default '3/4' */
  aspect?: string;
  /** Rank number shown in the corner badge. */
  rank?: ReactNode;
  title: ReactNode;
  handle?: ReactNode;
  /** Country flag emoji. */
  flag?: ReactNode;
  votes?: ReactNode;
  href?: string;
  onClick?: MouseEventHandler;
  className?: string;
  style?: CSSProperties;
}

/** Challenge entry tile — rank badge, title, creator handle + flag, vote count. */
export function EntryCard(props: EntryCardProps): JSX.Element;
