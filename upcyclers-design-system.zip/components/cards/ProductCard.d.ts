import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';

export interface ProductSeller {
  name: string;
  handle?: string;
  avatar?: string;
  initials?: string;
}

/**
 * Marketplace listing card.
 * @startingPoint section="Cards" subtitle="Marketplace product listing card" viewport="260x430"
 */
export interface ProductCardProps {
  image?: string;
  video?: string;
  poster?: string;
  alt?: string;
  /** @default '3/4' */
  aspect?: string;
  title: ReactNode;
  seller?: ProductSeller;
  /** Formatted price string, e.g. "$180.55". */
  price?: ReactNode;
  /** Heart / love count. */
  hearts?: ReactNode;
  /** Overlay badge pinned top-left (e.g. "Limited"). */
  badge?: ReactNode;
  saved?: boolean;
  onSave?: () => void;
  href?: string;
  onClick?: MouseEventHandler;
  className?: string;
  style?: CSSProperties;
}

export function ProductCard(props: ProductCardProps): JSX.Element;
