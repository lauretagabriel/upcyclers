**PersonCard** — a creator or challenge judge: portrait, uppercase name, red role line, short bio and a "See more →" link.

```jsx
<PersonCard image={portrait} name="Elle Walters" role="Founder, ELLERALI"
  bio="Filipino American upcycler and Upcycle Nation winner." link={{href:'#'}} />
```
