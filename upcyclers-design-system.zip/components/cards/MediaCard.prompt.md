**MediaCard** — the image/video card at the heart of every grid. Shows an image, or a video poster with a play badge, plus corner overlay slots and a free-form body. Hover lifts the card and zooms the media. Click to open a `Gallery`.

```jsx
<MediaCard image={url} aspect="3/4" onClick={openGallery}>…body…</MediaCard>
<MediaCard video={clip} poster={frame} topLeft={<Badge tone="solid">Reel</Badge>} />
```

Pass `video` to get the play affordance; `topLeft`/`topRight` for badges/actions.
