import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';

export interface PersonLink { label?: string; href?: string; }

export interface PersonCardProps {
  image?: string;
  video?: string;
  poster?: string;
  alt?: string;
  /** @default '4/3' */
  aspect?: string;
  name: ReactNode;
  /** Role / title line (shown in red). */
  role?: ReactNode;
  bio?: ReactNode;
  link?: PersonLink;
  href?: string;
  onClick?: MouseEventHandler;
  className?: string;
  style?: CSSProperties;
}

/** Creator / judge card — portrait, name, role, bio and a link. */
export function PersonCard(props: PersonCardProps): JSX.Element;
