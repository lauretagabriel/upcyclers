**ProductCard** — a marketplace listing: media, title, seller row, price and a save (heart) control. Composes `MediaCard`, so image or video both work.

```jsx
<ProductCard
  image={url} title="Aberdeen Jacket" price="$180.55"
  seller={{name:'22 Shades of Gray', handle:'@22shadesofgray'}}
  hearts="1.2k" saved={saved} onSave={toggle} href="#"
/>
```
