import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';

export interface CardProps {
  children?: ReactNode;
  /** Fill: panel (inset), surface (raised), plain (transparent), or any CSS color. @default 'panel' */
  surface?: 'panel' | 'surface' | 'plain' | string;
  /** @default true */
  padded?: boolean;
  /** Lift + shadow on hover. @default false */
  hoverable?: boolean;
  as?: keyof JSX.IntrinsicElements;
  href?: string;
  onClick?: MouseEventHandler;
  className?: string;
  style?: CSSProperties;
}

/** Base surface container — hairline border, brand radius. Compose freely. */
export function Card(props: CardProps): JSX.Element;
