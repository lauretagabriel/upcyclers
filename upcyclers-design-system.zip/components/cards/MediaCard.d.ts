import type { ReactNode, CSSProperties, MouseEventHandler } from 'react';

/**
 * Image/video media card with corner overlays and a body.
 * @startingPoint section="Cards" subtitle="Image or video card with overlays" viewport="260x420"
 */
export interface MediaCardProps {
  /** Image URL (also the video poster if `poster` is omitted). */
  image?: string;
  /** Video URL — shows a play affordance; open a Gallery on click to play. */
  video?: string;
  poster?: string;
  alt?: string;
  /** CSS aspect-ratio for the media box. @default '3/4' */
  aspect?: string;
  /** @default 'cover' */
  fit?: 'cover' | 'contain';
  /** Overlay node pinned top-left (e.g. a rank badge). */
  topLeft?: ReactNode;
  /** Overlay node pinned top-right (e.g. a save button). */
  topRight?: ReactNode;
  children?: ReactNode;
  bodyPadding?: string;
  onClick?: MouseEventHandler;
  href?: string;
  /** @default true */
  hoverable?: boolean;
  className?: string;
  style?: CSSProperties;
}

export function MediaCard(props: MediaCardProps): JSX.Element;
