import type { CSSProperties } from 'react';

export interface GalleryItem {
  type?: 'image' | 'video';
  src: string;
  /** Poster frame for videos / thumbnail override. */
  poster?: string;
  alt?: string;
  caption?: string;
}

export interface GalleryProps {
  /** Show the lightbox. @default false */
  open?: boolean;
  /** Media list — GalleryItem objects, or plain image-URL strings. */
  items: (GalleryItem | string)[];
  /** Controlled active index. */
  index?: number;
  /** Uncontrolled starting index. @default 0 */
  defaultIndex?: number;
  onIndexChange?: (i: number) => void;
  onClose?: () => void;
  /** Thumbnail rail (hidden for a single item). @default true */
  showThumbnails?: boolean;
  /** Wrap around at the ends. @default true */
  loop?: boolean;
  className?: string;
  style?: CSSProperties;
}

/**
 * Full-screen media lightbox: arrows, thumbnail rail, close, image + video,
 * Esc / ←/→ keyboard support. Open it from a card click.
 */
export function Gallery(props: GalleryProps): JSX.Element | null;
