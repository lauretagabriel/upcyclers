**Gallery** — the full-screen media lightbox opened when a user clicks a card that holds images or videos. Left/right arrows, a thumbnail rail below, an X close, image + video playback, and graceful keyboard handling (Esc closes, ←/→ navigate; body scroll locks while open).

```jsx
const [g, setG] = React.useState({open:false, i:0});
const media = [
  {type:'image', src:img1, alt:'Front'},
  {type:'video', src:clip, poster:frame, caption:'Boro mend, 60s'},
];
<MediaCard image={img1} onClick={() => setG({open:true, i:0})} />
<Gallery open={g.open} items={media} index={g.i}
  onIndexChange={(i)=>setG(s=>({...s,i}))} onClose={()=>setG(s=>({...s,open:false}))} />
```

`items` accepts objects or bare image-URL strings. Index is controlled (`index`/`onIndexChange`) or internal (`defaultIndex`).
