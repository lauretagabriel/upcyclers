import React from 'react';
import { Icon } from '../core/Icon.jsx';

function RoundBtn({ label, onClick, size = 48, children, style }) {
  const [h, setH] = React.useState(false);
  return (
    <button
      aria-label={label}
      onClick={(e) => { e.stopPropagation(); onClick(); }}
      onMouseEnter={() => setH(true)}
      onMouseLeave={() => setH(false)}
      style={{
        width: size, height: size, borderRadius: '50%', flex: '0 0 auto',
        border: '1px solid rgba(255,255,255,.22)',
        background: h ? 'rgba(255,255,255,.16)' : 'rgba(255,255,255,.06)',
        backdropFilter: 'var(--blur)', WebkitBackdropFilter: 'var(--blur)',
        color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center',
        justifyContent: 'center', padding: 0, transition: 'background var(--t-fast)', ...style,
      }}
    >{children}</button>
  );
}

/**
 * Gallery — full-screen media lightbox for cards that hold images or videos.
 * Left/right arrows, a thumbnail rail, a close button, image + video support,
 * and graceful keyboard handling (Esc closes, ←/→ navigate). Controlled via
 * `open` + `onClose`; the index is controlled (`index`/`onIndexChange`) or
 * internal (`defaultIndex`).
 */
export function Gallery({
  open = false,
  items = [],
  index,
  defaultIndex = 0,
  onIndexChange,
  onClose,
  showThumbnails = true,
  loop = true,
  className,
  style,
}) {
  const [internal, setInternal] = React.useState(defaultIndex);
  const controlled = index !== undefined;
  const cur = controlled ? index : internal;

  const go = React.useCallback((i) => {
    const n = items.length;
    if (n === 0) return;
    const next = loop ? ((i % n) + n) % n : Math.max(0, Math.min(n - 1, i));
    if (!controlled) setInternal(next);
    if (onIndexChange) onIndexChange(next);
  }, [items.length, loop, controlled, onIndexChange]);

  React.useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => {
      if (e.key === 'Escape') { if (onClose) onClose(); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); go(cur - 1); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); go(cur + 1); }
    };
    window.addEventListener('keydown', onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { window.removeEventListener('keydown', onKey); document.body.style.overflow = prevOverflow; };
  }, [open, cur, go, onClose]);

  if (!open || items.length === 0) return null;
  const item = items[cur] || items[0];
  const multi = items.length > 1;

  const norm = (m) => (typeof m === 'string' ? { type: 'image', src: m } : m);
  const it = norm(item);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Media gallery"
      className={['uc-gallery', className].filter(Boolean).join(' ')}
      onClick={() => onClose && onClose()}
      style={{
        position: 'fixed', inset: 0, zIndex: 'var(--z-overlay)',
        background: 'rgba(8,8,8,.94)', backdropFilter: 'var(--blur-strong)', WebkitBackdropFilter: 'var(--blur-strong)',
        display: 'flex', flexDirection: 'column', ...style,
      }}
    >
      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px clamp(16px,4vw,30px)', flex: '0 0 auto' }}>
        <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 'var(--fw-bold)', fontSize: 14, color: 'rgba(255,255,255,.72)', letterSpacing: '.04em' }}>
          {multi ? `${cur + 1} / ${items.length}` : ''}
        </div>
        <RoundBtn label="Close gallery" onClick={() => onClose && onClose()} size={42}>
          <Icon name="x" size={18} strokeWidth={2.2} />
        </RoundBtn>
      </div>

      {/* Stage */}
      <div style={{ flex: '1 1 auto', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 clamp(12px,5vw,72px)', minHeight: 0 }}>
        {multi ? (
          <div style={{ position: 'absolute', left: 'clamp(10px,3vw,26px)', top: '50%', transform: 'translateY(-50%)' }}>
            <RoundBtn label="Previous" onClick={() => go(cur - 1)}>
              <Icon name="chevron-left" size={20} strokeWidth={2.2} />
            </RoundBtn>
          </div>
        ) : null}

        <div onClick={(e) => e.stopPropagation()} style={{ maxWidth: 'min(1100px,86vw)', maxHeight: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
          {it.type === 'video' ? (
            <video
              key={cur}
              src={it.src}
              poster={it.poster}
              controls
              autoPlay
              playsInline
              style={{ maxWidth: '100%', maxHeight: '68vh', borderRadius: 'var(--radius-md)', background: '#000', display: 'block', boxShadow: 'var(--shadow-overlay)' }}
            />
          ) : (
            <img key={cur} src={it.src} alt={it.alt || ''} style={{ maxWidth: '100%', maxHeight: '72vh', objectFit: 'contain', borderRadius: 'var(--radius-md)', display: 'block', boxShadow: 'var(--shadow-overlay)' }} />
          )}
          {it.caption ? <div style={{ color: 'rgba(255,255,255,.7)', fontSize: 14, textAlign: 'center', maxWidth: 640 }}>{it.caption}</div> : null}
        </div>

        {multi ? (
          <div style={{ position: 'absolute', right: 'clamp(10px,3vw,26px)', top: '50%', transform: 'translateY(-50%)' }}>
            <RoundBtn label="Next" onClick={() => go(cur + 1)}>
              <Icon name="chevron-right" size={20} strokeWidth={2.2} />
            </RoundBtn>
          </div>
        ) : null}
      </div>

      {/* Thumbnail rail */}
      {showThumbnails && multi ? (
        <div onClick={(e) => e.stopPropagation()} style={{ flex: '0 0 auto', display: 'flex', gap: 10, justifyContent: 'center', flexWrap: 'nowrap', overflowX: 'auto', padding: '18px clamp(16px,4vw,30px) 24px', scrollbarWidth: 'none' }}>
          {items.map((m, i) => {
            const t = norm(m);
            const on = i === cur;
            return (
              <button
                key={i}
                aria-label={`Go to item ${i + 1}`}
                onClick={() => go(i)}
                style={{
                  position: 'relative', width: 64, height: 64, flex: '0 0 auto', padding: 0, cursor: 'pointer',
                  borderRadius: 'var(--radius-sm)', overflow: 'hidden', background: 'var(--chip)',
                  border: on ? '2px solid #fff' : '2px solid rgba(255,255,255,.2)', opacity: on ? 1 : 0.6,
                  transition: 'opacity var(--t-fast), border-color var(--t-fast)',
                }}
              >
                <img src={t.poster || t.src} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }} />
                {t.type === 'video' ? (
                  <span style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,.25)' }}>
                    <Icon name="play" size={14} filled color="#fff" />
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}
