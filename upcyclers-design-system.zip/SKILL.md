---
name: upcyclers-design
description: Use this skill to generate well-branded interfaces and assets for Upcyclers, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick map
- `readme.md` — the design guide: brand overview, sources, content fundamentals, visual foundations, iconography, and the full component / UI-kit index. **Start here.**
- `DESIGN.md` — living design-decisions log and do / don't rules.
- `styles.css` — the single stylesheet to link; `@import`s everything in `tokens/`.
- `tokens/` — colors (dark default + light), typography, spacing, effects, fonts, base reset.
- `assets/` — `upcyclers-white.png` (wordmark), `salvation-army.png` (collab), `fonts/*.woff2` (Bebas Neue + Montserrat), `image-slot.js`.
- `components/<group>/` — React primitives (`Button`, `Header`, `Footer`, `Tabs`, cards, `Gallery`, `Hero`, `Countdown`, …). Each has a `.d.ts` contract and a `.prompt.md` with a usage example.
- `guidelines/` — foundation specimen cards. `ui_kits/` — homepage / challenge / product recreations.
- `templates/` — ready-to-copy starting pages.

## How to build with it
- **Static HTML / prototype:** link `styles.css`, set `data-theme="dark"` (default) or `"light"` on a wrapper, and use the CSS custom properties. Copy any assets you reference into your output. Mirror the patterns in `ui_kits/` — compose from the components rather than restyling from scratch.
- **Production React:** read each component's `.jsx` + `.d.ts` and reimplement/port against the same tokens. Copy exact values from `tokens/`; never round them.
- **Brand rules that matter most:** black + white + one red used at ~5–10%; Bebas Neue for display, Montserrat for everything (800 / -.03em for the mega hero); flat surfaces separated by hairline borders, not shadows; pill buttons and chips; quick understated motion. See `DESIGN.md` for the full do / don't list.
