# DESIGN.md — Upcyclers living design doc

A working log of design decisions, conventions and rules. `readme.md` is the guide + index; **this** file is where we record *why* things are the way they are and iterate over time. Update it as the system evolves.

---

## Principles

1. **Clean, minimal, visual, scannable.** Built for short attention spans — big type, lots of air, one idea per block, imagery leading. If a block feels empty, it's a layout problem, not a reason to add filler.
2. **Black, white, and a little red.** Red (`#ee3124`) is a spice, not a sauce — target ~5–10% of any view. Everything structural is monochrome.
3. **The material is the hero.** Real product/creator photography carries the pages; chrome stays quiet so the garments pop.
4. **Flat, not glossy.** Separation comes from hairline borders and solid surfaces. Shadows are reserved for things that truly float (lightbox, hover-lift).
5. **Mobile-first and responsive.** Every component reflows; grids use `auto-fit`/`auto-fill` with `minmax`; type uses `clamp()`. Hit targets ≥ 44px.
6. **Honest about placeholders.** Where real media isn't available, use `image-slot` placeholders rather than faking content.

---

## Key decisions & rationale

- **Dark is the default theme.** Both source surfaces (product + challenge) ship dark; the brand reads as a premium, gallery-like black. Light is a faithful inversion for contexts that need it. Tokens live on `:root` (dark) and `[data-theme="light"]`.
- **Red recedes in light mode.** In light theme `--accent` becomes ink and the true red only survives on `--accent-2`. This keeps red at the same low volume on white as on black (copied verbatim from the product build — don't "fix" it).
- **Two display treatments, on purpose.** Bebas Neue (condensed caps) for titles / numbers / timers; Montserrat 800 ultra-tight (`-.03em`, `.86`) for the mega hashtag hero. Using both is intentional, not inconsistent.
- **Self-hosted webfonts.** Bebas Neue + Montserrat (variable) woff2 were lifted from the brand's own build and live in `assets/fonts/`. If licensed binaries arrive, swap them in `tokens/fonts.css`. *(Flagged: these are the Google Fonts versions.)*
- **Components are inline-styled against tokens.** No CSS-in-JS libs, no per-component stylesheets — every value is a `var(--token)` so theming and edits stay centralized.
- **Cards support image AND video.** `MediaCard` is the base; `ProductCard`/`EntryCard`/`PersonCard` compose it. A `video` shows a play affordance and opens the `Gallery`.

---

## Component API conventions

- Named PascalCase export per file; props typed in the sibling `.d.ts`; a `.prompt.md` shows the one-line "what & when" + an example.
- Common props: `className`, `style` (merged last so callers can override), and `href` → renders an `<a>`, else `<button>`/`<div>`.
- Interactive components manage hover/press with local state; press scales to `--press-scale` (.97), hover dims/lifts per `--hover-dim` / `--shadow-pop`.
- Controlled **and** uncontrolled where it matters (`Tabs`, `Accordion`, `Gallery`): pass `value`/`index` to control, or `defaultValue`/`defaultIndex` to let the component own it.
- Icons are inline stroke SVGs (2–2.2px, round caps, `currentColor`). No icon-font dependency.

---

## Accessibility

- `Gallery` is `role="dialog" aria-modal`, traps nothing but handles Esc/←/→, locks body scroll, and restores it on close.
- Tabs use `role="tablist"/"tab"` + `aria-selected`; accordion buttons use `aria-expanded`; icon-only buttons carry `aria-label`.
- Respect `prefers-reduced-motion` (handled in `tokens/base.css`).
- Maintain text contrast: never place `--muted-2`/`--faint` text on `--panel` for essential copy.

---

## Do / Don't

**Do**
- Use `Eyebrow` kickers above section titles; keep titles in Bebas.
- Keep red to accents: active tab underline, seconds digit, one highlighted stat, a heart, a short underline.
- Reach for `Stat` for any big-number moment (impact, prizes, judging weights).
- Let media go edge-to-edge inside rounded card frames (`overflow:hidden`).

**Don't**
- Don't add gradients, glows, or coloured drop shadows.
- Don't fill areas with red or use red for large surfaces / long text.
- Don't hand-draw the logo — use `assets/upcyclers-white.png` (fallback: plain "Upcyclers." text).
- Don't round token values to a grid — copy them exactly.
- Don't introduce new fonts or a third accent colour without updating this doc.

---

## Roadmap / open questions (iterate here)

- [ ] Confirm licensed vs. Google-Fonts webfonts (currently the Google versions).
- [ ] Do we need logged-in surfaces (seller dashboard, listing composer, messaging)? Scoped out for now — public pages only.
- [ ] Swipe-discovery mobile feed (from the vision doc) — worth a dedicated `SwipeCard` component?
- [ ] Livestream + virtual-gift UI — not yet designed.
- [ ] Add real, distinct product photography to replace the cycled demo set in the kits.
- [ ] Decide whether light theme is a shipping surface or dark-only for marketing.
