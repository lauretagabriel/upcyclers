# Upcyclers Design System

The brand + UI system for **Upcyclers** — *where creators find inspiration, learn techniques, source materials, create one-of-a-kind products, and sell what they make, all in one place.*

Upcyclers brings secondhand clothing, vintage garments, deadstock and reclaimed textiles together with the tools to turn them into products with new life and value. The platform spans discovery, learning, creation, community, commerce, quarterly challenges and celebrity drops. This design system captures the black / white / red visual language and the reusable UI used across the public (logged-out) surfaces.

- **Website:** https://www.upcyclers.com/
- **Sample challenge page:** https://www.upcyclers.com/events/global-upcycling-challenge-2026

---

## Sources this system was built from

Everything here was reverse-engineered from real, provided artifacts (not from memory):

| Source | What it is | Where |
| --- | --- | --- |
| `product/index.html` | The **Product details page** — a full Design Component with the complete token set (dark + light themes), gallery, purchase panel, accordions, impact stats, reviews/comments tabs. Ground truth for tokens + patterns. | Attached local folder `product/` (File System Access mount) |
| `uploads/challege-page-template.html` | The **Quarterly Challenge page** (`#thriftflip`, Upcyclers × The Salvation Army Thrift Stores). Bundled single-file DC; hero, countdown, judging tabs, judges, rules, Top-10 grid. | Project uploads |
| `uploads/upcyclers-logo.svg` | White wordmark (wrapped raster; the usable PNG is `assets/upcyclers-white.png`). | Project uploads |
| `uploads/upcyclers-product-vision.md` | Master product vision (20 sections — marketplace, seller tools, community, challenges, AI, impact). Reference only. | Project uploads |

Extracted into `assets/`: the real webfonts (Bebas Neue + Montserrat woff2, from the challenge build), `upcyclers-white.png` (wordmark 509×120), `salvation-army.png` (collab shield 128×207), and `image-slot.js` (the brand's drag-drop media placeholder web component). Demo imagery across the kits uses Unsplash fashion photography (`images.unsplash.com/...`); swap in real media per listing in production.

> **Font note:** Bebas Neue and Montserrat are Google Fonts, self-hosted here as woff2 lifted from the brand's own build. Montserrat is the variable file (weights 400–900). If you have licensed/branded font binaries you'd prefer, drop them in `assets/fonts/` and update `tokens/fonts.css`.

---

## Content fundamentals

How Upcyclers writes. The voice is **confident, plainspoken and maker-first** — it talks *to* the creator, celebrates craft and the story in the material, and keeps sustainability factual rather than preachy.

- **Person & address:** Second person ("Turn thrifted finds into one-of-a-kind", "Everything you need to know"). Imperative CTAs ("Submit Entry", "Add to cart", "Shop the Look").
- **Casing:** Sentence case for body and most headings. **Bebas Neue display is inherently all-caps** (it has no lowercase), so section titles read as caps by virtue of the typeface. Small labels/eyebrows are deliberately UPPERCASE with wide tracking. The wordmark is "Upcyclers." (capital U, trailing period).
- **Hashtags & campaigns** are lowercase: `#thriftflip`. Handles are lowercase with a dot style: `@22shadesofgray`, `@boro.boro`.
- **Tone:** Warm but economical. Short sentences. Concrete nouns (denim, seams, salvaged panels) over adjectives. "One-of-a-kind" is a recurring value phrase.
- **Impact language:** Numbers first, quiet framing — "2,000L water saved · Est. vs. new denim", "1 garment rescued · Diverted from landfill". Always labels estimates as estimates.
- **Marketplace copy:** Verified, trustworthy, specific — measurements in both in/cm, "Includes standard shipping", "As a one-of-a-kind piece, please review the measurements."
- **Emoji:** Used sparingly and only where meaningful — country flags on challenge entries (🇺🇸 🇰🇷), the ♥ heart for votes/saves, gift glyphs (🌸 💐) for tips. Not used decoratively in marketing copy.
- **Examples of headline voice:** "Everything you need to know" · "Top 10 Most Loved" · "The ten most-loved entries advance to the finals." · "Rack up hearts."

---

## Visual foundations

**Palette.** Near-black `#0a0a0a`, pure white `#ffffff`, and a single brand red `#ee3124`. Red is an **accent used sparingly (~5–10% of any view)**: the seconds digit in a countdown, a heart, an active tab underline, one highlighted stat number, an eyebrow on dark, a short underline emphasis. Never large red fills. **Dark is the default theme;** light is a faithful inversion where red recedes even further (eyebrows become ink; the true red only appears on `--accent-2`).

**Type.** Two families, two jobs:
- **Bebas Neue** — condensed all-caps *display*: section titles, huge stat numbers, countdown digits, accordion +/- signs. Letter-spacing ~.02em, line-height ~.9–1.
- **Montserrat** (variable 400–900) — everything else, **plus** the signature heavy hero (`800`, letter-spacing `-.03em`, line-height `.86` — the `#thriftflip` treatment). Body 400–600; UI labels 600–800; eyebrows 700 uppercase, tracking `.16em`.

**Layout.** Centered max-widths (1400 nav/footer, 1200 content, 1000 hero prose) with a fluid side gutter `clamp(16px,4vw,30px)`. Generous vertical section rhythm. Content is centered and airy; challenge/marketing surfaces are centered editorial, product surfaces are 2-column.

**Surfaces & separation.** The system is **flat** — separation comes from **hairline borders** (`rgba(255,255,255,.08)`) and solid/near-solid surfaces, *not* drop shadows. Cards: `--surface-2 #141414` or inset `--panel`, `1px` border, radius **14px** (16px for feature/gallery). Chips & buttons are fully rounded pills. Cards never lift or cast a shadow — a shadow appears only on the floating Gallery lightbox overlay.

**Imagery.** Real, warm product/creator photography shot against neutral grounds; portrait 3/4 for products & entries, 4/3 for people. Media is edge-to-edge inside rounded card frames (`overflow:hidden`). Demo screens pull from Unsplash; where imagery isn't supplied, the brand uses a drag-drop `image-slot` placeholder.

**Motion.** Quick and understated — short fades and color/opacity/transform shifts (`.18–.25s ease`). No bounces or springs. Hover: subtle media zoom (`scale 1.04`) + border brighten — cards do **not** lift or cast a shadow; primary buttons dim to `.86`; links/tabs shift to red. Press: scale `.97`. Respects `prefers-reduced-motion`.

**Borders / radii / blur.** Border 1px hairline; radii 10 / 14 / 16 / pill; backdrop-blur only on badges over media and the lightbox scrim. Selection highlight is red.

---

## Iconography

Upcyclers uses **inline stroke SVG icons**, not an icon font, emoji-as-icons, or raster icons. Observed set: search (magnifier), theme sun/moon, hamburger (three unequal bars, built from divs), directional arrows (rendered as the `→` glyph in copy, stroked chevrons for gallery nav), and a close X. Stroke weight ~2–2.2, `stroke-linecap:round`, `currentColor`. The ♥/♡ heart is used as a text glyph for votes/saves. Country-flag emoji tag challenge entries.

- **Approach in this system:** icons are inlined as small SVGs directly inside components (`Header`, `Gallery`, `MediaCard` play glyph, etc.) — no external icon dependency. If you need a broader set, match this style (2px stroke, round caps, `currentColor`) — **Lucide** (https://lucide.dev, CDN-available) is the closest match and a safe substitute; flag any substitution.
- Do **not** hand-draw the Upcyclers logo — use `assets/upcyclers-white.png`. The mark is a wordmark with a small sprout on the "U"; components fall back to plain "Upcyclers." text when no `logoSrc` is passed.

---

## What's in here (index)

**Root**
- `styles.css` — the single entry point consumers link. `@import`s only.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css`, `base.css`.
- `assets/` — `upcyclers-white.png`, `salvation-army.png`, `fonts/*.woff2`, `image-slot.js`.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand) for the Design System tab.
- `DESIGN.md` — living design decisions log. `SKILL.md` — portable Agent-Skill manifest.

**Components** (`components/<group>/`, mounted as `window.UpcyclersDesignSystem_2f4fb9.<Name>`)
- **core/** — `Button`, `Tag`, `Badge`, `Avatar`, `Eyebrow`, `Stat`
- **navigation/** — `Header`, `Footer`, `AnnouncementBar`, `Tabs`
- **cards/** — `Card`, `MediaCard`, `ProductCard`, `EntryCard`, `PersonCard` *(all support image + video)*
- **media/** — `Gallery` *(full-screen lightbox: arrows, thumbnail rail, X, keyboard, image + video)*
- **sections/** — `Hero`, `ChallengeHero`, `Countdown`, `Accordion`

**UI kits** (`ui_kits/<product>/` — high-fidelity click-through recreations)
- **homepage/** — marketing homepage (spotlight challenge hero, editorial celebrity drop, Top 10 grid, community, marketplace, auto-scroll feeds, masonry, hall of fame, footer)
- **challenge/** — the `#thriftflip` quarterly challenge page
- **product/** — the product details page (gallery → lightbox, purchase panel, reviews/comments)

Every reusable primitive is one `Name.jsx` + `Name.d.ts` (+ `Name.prompt.md`); each component directory has a `*.card.html` thumbnail tagged for the Design System tab. Components reference styling exclusively through the CSS custom properties in `tokens/`.

---

## Intentional additions

The two provided sources define the product/challenge patterns; these primitives were factored out to make the system reusable and to cover the explicitly-requested inventory (Buttons, Header, Footer, Cards, Tabs, Hero, Gallery):

- `Gallery` — the requested media lightbox; not present in the sources, built to the brief (arrows, thumbnail rail, X, keyboard, image + video).
- `Tag`, `Badge`, `Avatar`, `Eyebrow`, `Stat`, `Card`, `Countdown`, `Accordion` — extracted from repeated inline patterns in the product + challenge pages so they're not re-implemented per screen.
- `ChallengeHero` — the featured quarterly-challenge hero for the homepage and the reusable template for each new challenge. A decluttered recreation of the live `#thriftflip` hero: the legacy restatements of the deadline collapse into one faint deadline line + countdown, the edition rides above the title as the eyebrow, and the prize/date blocks become one quiet facts strip (prize white with a red underline; a fact can carry a small `sub` caption). The cutout image fills the section as a bottom-right background; ships `spotlight` by default with `editorial` / `panel` variants.
